var require = meteorInstall({"imports":{"api":{"gql":{"categories.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/gql/categories.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _regenerator = require("babel-runtime/regenerator");                                                          //
                                                                                                                  //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                         //
                                                                                                                  //
var _extends2 = require("babel-runtime/helpers/extends");                                                         //
                                                                                                                  //
var _extends3 = _interopRequireDefault(_extends2);                                                                //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
module.export({                                                                                                   // 1
    typeDefs: function () {                                                                                       // 1
        return typeDefs;                                                                                          // 1
    },                                                                                                            // 1
    resolvers: function () {                                                                                      // 1
        return resolvers;                                                                                         // 1
    }                                                                                                             // 1
});                                                                                                               // 1
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
    Meteor: function (v) {                                                                                        // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
var Categories = void 0,                                                                                          // 1
    Tasks = void 0;                                                                                               // 1
module.watch(require("../../collections"), {                                                                      // 1
    Categories: function (v) {                                                                                    // 1
        Categories = v;                                                                                           // 1
    },                                                                                                            // 1
    Tasks: function (v) {                                                                                         // 1
        Tasks = v;                                                                                                // 1
    }                                                                                                             // 1
}, 1);                                                                                                            // 1
var regex = void 0;                                                                                               // 1
module.watch(require("../../utils/regex"), {                                                                      // 1
    "default": function (v) {                                                                                     // 1
        regex = v;                                                                                                // 1
    }                                                                                                             // 1
}, 2);                                                                                                            // 1
var _regex = regex,                                                                                               //
    buildRegExp = _regex.buildRegExp;                                                                             //
var typeDefs = "\n                type Category {\n                  _id: String\n                  name: String\n                  created_at: Date\n                  taskList: [Task] # the list of Task by this category\n                }\n                type Query {\n                  categories : [Category]\n                  category (\n                    name: String!\n                  ): Category\n                }\n                type Mutation {\n                    createCategory (\n                      name: String!\n                    ): Category\n                }";
var resolvers = {                                                                                                 // 26
    Query: {                                                                                                      // 27
        categories: function (root, args, context) {                                                              // 28
            return Categories.find({                                                                              // 29
                created_by: 'admin'                                                                               // 29
            }).fetch();                                                                                           // 29
        },                                                                                                        // 31
        category: function (root, _ref, context) {                                                                // 32
            var name = _ref.name;                                                                                 // 32
            return Categories.findOne({                                                                           // 33
                name: buildRegExp(name),                                                                          // 33
                created_by: 'admin'                                                                               // 33
            });                                                                                                   // 33
        }                                                                                                         // 34
    },                                                                                                            // 27
    Mutation: {                                                                                                   // 36
        createCategory: function () {                                                                             // 37
            function _callee(root, _ref2, context) {                                                              // 36
                var name = _ref2.name;                                                                            // 36
                                                                                                                  //
                var data, _id;                                                                                    // 36
                                                                                                                  //
                return _regenerator2.default.async(function () {                                                  // 36
                    function _callee$(_context) {                                                                 // 36
                        while (1) {                                                                               // 36
                            switch (_context.prev = _context.next) {                                              // 36
                                case 0:                                                                           // 36
                                    data = {                                                                      // 38
                                        name: name,                                                               // 38
                                        created_by: 'admin',                                                      // 38
                                        created_at: new Date(),                                                   // 38
                                        updated_at: new Date()                                                    // 38
                                    };                                                                            // 38
                                    _id = Categories.insert(data);                                                // 39
                                    return _context.abrupt("return", (0, _extends3.default)({                     // 36
                                        _id: _id                                                                  // 40
                                    }, data));                                                                    // 36
                                                                                                                  //
                                case 3:                                                                           // 36
                                case "end":                                                                       // 36
                                    return _context.stop();                                                       // 36
                            }                                                                                     // 36
                        }                                                                                         // 36
                    }                                                                                             // 36
                                                                                                                  //
                    return _callee$;                                                                              // 36
                }(), null, this);                                                                                 // 36
            }                                                                                                     // 36
                                                                                                                  //
            return _callee;                                                                                       // 36
        }()                                                                                                       // 36
    },                                                                                                            // 36
    Category: {                                                                                                   // 43
        taskList: function (_ref3) {                                                                              // 44
            var _id = _ref3._id;                                                                                  // 44
            return Tasks.find({                                                                                   // 45
                cat_id: _id                                                                                       // 45
            }).fetch();                                                                                           // 45
        }                                                                                                         // 47
    }                                                                                                             // 43
};                                                                                                                // 26
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"date.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/gql/date.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({                                                                                                   // 1
    typeDefs: function () {                                                                                       // 1
        return typeDefs;                                                                                          // 1
    },                                                                                                            // 1
    scalarType: function () {                                                                                     // 1
        return scalarType;                                                                                        // 1
    },                                                                                                            // 1
    resolvers: function () {                                                                                      // 1
        return resolvers;                                                                                         // 1
    }                                                                                                             // 1
});                                                                                                               // 1
var Kind = void 0;                                                                                                // 1
module.watch(require("graphql/language"), {                                                                       // 1
    Kind: function (v) {                                                                                          // 1
        Kind = v;                                                                                                 // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
var isNumber = void 0;                                                                                            // 1
module.watch(require("lodash/isNumber"), {                                                                        // 1
    "default": function (v) {                                                                                     // 1
        isNumber = v;                                                                                             // 1
    }                                                                                                             // 1
}, 1);                                                                                                            // 1
var typeDefs = "\n\t\t\t\tscalar Date\n                ";                                                         // 4
var scalarType = {                                                                                                // 8
    description: 'Date custom scalar type',                                                                       // 10
    __parseValue: function (value) {                                                                              // 12
        return new Date(value); // value from the client                                                          // 13
    },                                                                                                            // 14
    __serialize: function (value) {                                                                               // 15
        if (isNumber(value)) {                                                                                    // 16
            return value;                                                                                         // 17
        } else {                                                                                                  // 18
            return value.getTime(); // value sent to the client                                                   // 19
        }                                                                                                         // 20
    },                                                                                                            // 21
    __parseLiteral: function (ast) {                                                                              // 22
        switch (ast.kind) {                                                                                       // 23
            case Kind.INT:                                                                                        // 24
            case Kind.FLOAT:                                                                                      // 25
                return new Date(parseFloat(ast.value));                                                           // 26
                                                                                                                  //
            default:                                                                                              // 27
                return null;                                                                                      // 28
        }                                                                                                         // 23
    }                                                                                                             // 30
};                                                                                                                // 8
var resolvers = {                                                                                                 // 33
    Date: scalarType                                                                                              // 34
};                                                                                                                // 33
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hello.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/gql/hello.js                                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({                                                                                                   // 1
    typeDefs: function () {                                                                                       // 1
        return typeDefs;                                                                                          // 1
    },                                                                                                            // 1
    resolvers: function () {                                                                                      // 1
        return resolvers;                                                                                         // 1
    }                                                                                                             // 1
});                                                                                                               // 1
var typeDefs = "\n\t\t\t\t\ttype Query {\n\t\t\t\t\t  say (\n                \t\t\tsomething: String!\n              \t\t\t): String\n\t\t\t\t\t}";
var resolvers = {                                                                                                 // 8
    Query: {                                                                                                      // 9
        say: function (root, _ref, context) {                                                                     // 10
            var something = _ref.something;                                                                       // 10
            return "hello " + something;                                                                          // 11
        }                                                                                                         // 12
    }                                                                                                             // 9
};                                                                                                                // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"indiecore.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/gql/indiecore.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({                                                                                                   // 1
    typeDefs: function () {                                                                                       // 1
        return typeDefs;                                                                                          // 1
    },                                                                                                            // 1
    resolvers: function () {                                                                                      // 1
        return resolvers;                                                                                         // 1
    }                                                                                                             // 1
});                                                                                                               // 1
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
    Meteor: function (v) {                                                                                        // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
var HTTP = void 0;                                                                                                // 1
module.watch(require("meteor/http"), {                                                                            // 1
    HTTP: function (v) {                                                                                          // 1
        HTTP = v;                                                                                                 // 1
    }                                                                                                             // 1
}, 1);                                                                                                            // 1
var typeDefs = "\n                # Business List\n                type BusinessRecord {\n                  business_id: String\n                  name: String\n                  location: [String]\n                  display_address: String\n                  image_url: String\n                  types: [String]\n                  hasPhoto: Boolean\n                  user_count: Int\n                  distance: String\n                }\n                # Indiecore\n                type Business {\n                  list: [BusinessRecord]\n                  places_count: String\n                  total_count: String\n                }\n                type Query {\n                  business (\n                    longitude: String!\n                    latitude: String!\n                    sort: String\n                    offset: String\n                  ): Business\n                }";
var resolvers = {                                                                                                 // 32
    Query: {                                                                                                      // 33
        business: function (root, _ref, context) {                                                                // 34
            var longitude = _ref.longitude,                                                                       // 34
                latitude = _ref.latitude,                                                                         // 34
                _ref$sort = _ref.sort,                                                                            // 34
                sort = _ref$sort === undefined ? '0' : _ref$sort,                                                 // 34
                _ref$offset = _ref.offset,                                                                        // 34
                offset = _ref$offset === undefined ? '0' : _ref$offset;                                           // 34
                                                                                                                  //
            var _HTTP$post = HTTP.post("http://indiecorelive.ignivastaging.com/api/v1/business/records", {        // 34
                data: {                                                                                           // 37
                    userId: 'J2iyEjdeP5iikLy6q',                                                                  // 38
                    token: 'noy1OssDlGIUwfHVVAHlfhbQUp-nstPVWZPxUHIUfjm',                                         // 39
                    longitude: longitude,                                                                         // 40
                    latitude: latitude,                                                                           // 41
                    sort: sort,                                                                                   // 42
                    offset: offset                                                                                // 43
                }                                                                                                 // 37
            }),                                                                                                   // 36
                data = _HTTP$post.data;                                                                           // 34
                                                                                                                  //
            if (data.success) return data;                                                                        // 47
            throw new Meteor.Error("query-failed", data.error_text);                                              // 50
        }                                                                                                         // 52
    },                                                                                                            // 33
    Business: {                                                                                                   // 54
        list: function (_ref2) {                                                                                  // 55
            var places_list = _ref2.places_list;                                                                  // 55
            return places_list;                                                                                   // 56
        }                                                                                                         // 57
    }                                                                                                             // 54
};                                                                                                                // 32
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"json.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/gql/json.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({                                                                                                   // 1
    typeDefs: function () {                                                                                       // 1
        return typeDefs;                                                                                          // 1
    },                                                                                                            // 1
    scalarType: function () {                                                                                     // 1
        return scalarType;                                                                                        // 1
    },                                                                                                            // 1
    resolvers: function () {                                                                                      // 1
        return resolvers;                                                                                         // 1
    }                                                                                                             // 1
});                                                                                                               // 1
var Kind = void 0;                                                                                                // 1
module.watch(require("graphql/language"), {                                                                       // 1
    Kind: function (v) {                                                                                          // 1
        Kind = v;                                                                                                 // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
var typeDefs = "\n                scalar JSON\n                ";                                                 // 3
var scalarType = {                                                                                                // 7
    description: 'The `JSON` scalar type represents JSON values as specified by ' + '[ECMA-404](http://www.ecma-international.org/' + 'publications/files/ECMA-ST/ECMA-404.pdf).',
    __parseValue: function (value) {                                                                              // 13
        return value; // value from the client                                                                    // 14
    },                                                                                                            // 15
    __serialize: function (value) {                                                                               // 16
        return value; // value sent to the client                                                                 // 17
    },                                                                                                            // 18
    __parseLiteral: function (ast) {                                                                              // 19
        switch (ast.kind) {                                                                                       // 20
            case Kind.STRING:                                                                                     // 21
            case Kind.BOOLEAN:                                                                                    // 22
                return ast.value;                                                                                 // 23
                                                                                                                  //
            case Kind.INT:                                                                                        // 24
            case Kind.FLOAT:                                                                                      // 25
                return parseFloat(ast.value);                                                                     // 26
                                                                                                                  //
            case Kind.OBJECT:                                                                                     // 27
                {                                                                                                 // 28
                    var value = Object.create(null);                                                              // 29
                    ast.fields.forEach(function (field) {                                                         // 30
                        value[field.name.value] = parseLiteral(field.value);                                      // 31
                    });                                                                                           // 32
                    return value;                                                                                 // 34
                }                                                                                                 // 35
                                                                                                                  //
            case Kind.LIST:                                                                                       // 36
                return ast.values.map(parseLiteral);                                                              // 37
                                                                                                                  //
            default:                                                                                              // 38
                return null;                                                                                      // 39
        }                                                                                                         // 20
    }                                                                                                             // 41
};                                                                                                                // 7
var resolvers = {                                                                                                 // 44
    JSON: scalarType                                                                                              // 45
};                                                                                                                // 44
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"response.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/gql/response.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({                                                                                                   // 1
																	typeDefs: function () {                                                                          // 1
																																		return typeDefs;                                                                // 1
																	}                                                                                                // 1
});                                                                                                               // 1
var typeDefs = "\n\t\t\t\t\ttype Response {\n\t\t\t\t\t  success : String\n                      message : String\n\t\t\t\t\t}";
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tasks.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/gql/tasks.js                                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _regenerator = require("babel-runtime/regenerator");                                                          //
                                                                                                                  //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                         //
                                                                                                                  //
var _extends2 = require("babel-runtime/helpers/extends");                                                         //
                                                                                                                  //
var _extends3 = _interopRequireDefault(_extends2);                                                                //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
module.export({                                                                                                   // 1
    typeDefs: function () {                                                                                       // 1
        return typeDefs;                                                                                          // 1
    },                                                                                                            // 1
    resolvers: function () {                                                                                      // 1
        return resolvers;                                                                                         // 1
    }                                                                                                             // 1
});                                                                                                               // 1
var Categories = void 0,                                                                                          // 1
    Tasks = void 0;                                                                                               // 1
module.watch(require("../../collections"), {                                                                      // 1
    Categories: function (v) {                                                                                    // 1
        Categories = v;                                                                                           // 1
    },                                                                                                            // 1
    Tasks: function (v) {                                                                                         // 1
        Tasks = v;                                                                                                // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
var withFilter = void 0;                                                                                          // 1
module.watch(require("graphql-subscriptions"), {                                                                  // 1
    withFilter: function (v) {                                                                                    // 1
        withFilter = v;                                                                                           // 1
    }                                                                                                             // 1
}, 1);                                                                                                            // 1
var pubsub = void 0;                                                                                              // 1
module.watch(require("../subscriptions"), {                                                                       // 1
    "default": function (v) {                                                                                     // 1
        pubsub = v;                                                                                               // 1
    }                                                                                                             // 1
}, 2);                                                                                                            // 1
var logger = void 0;                                                                                              // 1
module.watch(require("../../utils/logger"), {                                                                     // 1
    "default": function (v) {                                                                                     // 1
        logger = v;                                                                                               // 1
    }                                                                                                             // 1
}, 3);                                                                                                            // 1
var typeDefs = "\n                # Description for the type\n                type Task {\n                  _id: String\n                  title: String\n                  complete: Boolean\n                  created_at: Date\n                  updated_at: Date # @deprecated(reason: \"Use otherField instead.\")\n                }\n                type Query {\n                  tasks : [Task]\n                }\n                type Mutation {\n                  createTask (\n                    # Description for argument\n                    title: String!\n                    cId: String!\n                  ): Task\n                  toggleTask (\n                    tId: String!\n                  ): Task\n                }\n                type Subscription {\n                  taskAdded: Task\n                }\n              ";
var resolvers = {                                                                                                 // 33
    Query: {                                                                                                      // 34
        tasks: function (root, args, context) {                                                                   // 35
            return Tasks.find({                                                                                   // 36
                created_by: 'admin'                                                                               // 36
            }).fetch();                                                                                           // 36
        }                                                                                                         // 38
    },                                                                                                            // 34
    Mutation: {                                                                                                   // 40
        createTask: function () {                                                                                 // 41
            function _callee(root, _ref, context) {                                                               // 40
                var title = _ref.title,                                                                           // 40
                    cId = _ref.cId;                                                                               // 40
                                                                                                                  //
                var data, _id;                                                                                    // 40
                                                                                                                  //
                return _regenerator2.default.async(function () {                                                  // 40
                    function _callee$(_context) {                                                                 // 40
                        while (1) {                                                                               // 40
                            switch (_context.prev = _context.next) {                                              // 40
                                case 0:                                                                           // 40
                                    if (!Categories.findOne(cId)) {                                               // 40
                                        _context.next = 6;                                                        // 40
                                        break;                                                                    // 40
                                    }                                                                             // 40
                                                                                                                  //
                                    data = {                                                                      // 43
                                        title: title,                                                             // 43
                                        cat_id: cId,                                                              // 43
                                        complete: false,                                                          // 43
                                        created_by: 'admin',                                                      // 43
                                        created_at: new Date(),                                                   // 43
                                        updated_at: new Date()                                                    // 43
                                    };                                                                            // 43
                                    _id = Tasks.insert(data);                                                     // 44
                                    logger.log('subscribe', pubsub);                                              // 45
                                    pubsub.publish('taskAdded', {                                                 // 46
                                        taskAdded: (0, _extends3.default)({                                       // 46
                                            _id: _id                                                              // 46
                                        }, data)                                                                  // 46
                                    });                                                                           // 46
                                    return _context.abrupt("return", (0, _extends3.default)({                     // 40
                                        _id: _id                                                                  // 47
                                    }, data));                                                                    // 40
                                                                                                                  //
                                case 6:                                                                           // 40
                                    throw new Meteor.Error("mutation-denied", "category - not found");            // 40
                                                                                                                  //
                                case 7:                                                                           // 40
                                case "end":                                                                       // 40
                                    return _context.stop();                                                       // 40
                            }                                                                                     // 40
                        }                                                                                         // 40
                    }                                                                                             // 40
                                                                                                                  //
                    return _callee$;                                                                              // 40
                }(), null, this);                                                                                 // 40
            }                                                                                                     // 40
                                                                                                                  //
            return _callee;                                                                                       // 40
        }(),                                                                                                      // 40
        toggleTask: function () {                                                                                 // 51
            function _callee2(root, _ref2, context) {                                                             // 40
                var tId = _ref2.tId;                                                                              // 40
                var task, mods;                                                                                   // 40
                return _regenerator2.default.async(function () {                                                  // 40
                    function _callee2$(_context2) {                                                               // 40
                        while (1) {                                                                               // 40
                            switch (_context2.prev = _context2.next) {                                            // 40
                                case 0:                                                                           // 40
                                    task = Tasks.findOne({                                                        // 52
                                        _id: tId,                                                                 // 52
                                        created_by: 'admin'                                                       // 52
                                    });                                                                           // 52
                                                                                                                  //
                                    if (!task) {                                                                  // 40
                                        _context2.next = 5;                                                       // 40
                                        break;                                                                    // 40
                                    }                                                                             // 40
                                                                                                                  //
                                    mods = {                                                                      // 54
                                        complete: !task.complete,                                                 // 54
                                        updated_at: new Date()                                                    // 54
                                    };                                                                            // 54
                                    Tasks.update({                                                                // 55
                                        _id: tId                                                                  // 55
                                    }, {                                                                          // 55
                                        $set: mods                                                                // 55
                                    });                                                                           // 55
                                    return _context2.abrupt("return", (0, _extends3.default)({}, task, mods));    // 40
                                                                                                                  //
                                case 5:                                                                           // 40
                                    throw new Meteor.Error("mutation-denied", "task - not found");                // 40
                                                                                                                  //
                                case 6:                                                                           // 40
                                case "end":                                                                       // 40
                                    return _context2.stop();                                                      // 40
                            }                                                                                     // 40
                        }                                                                                         // 40
                    }                                                                                             // 40
                                                                                                                  //
                    return _callee2$;                                                                             // 40
                }(), null, this);                                                                                 // 40
            }                                                                                                     // 40
                                                                                                                  //
            return _callee2;                                                                                      // 40
        }()                                                                                                       // 40
    },                                                                                                            // 40
    Subscription: {                                                                                               // 61
        taskAdded: {                                                                                              // 62
            subscribe: function () {                                                                              // 63
                return pubsub.asyncIterator('taskAdded');                                                         // 63
            } // resolve: (payload) => {                                                                          // 63
            //     return payload.taskAdded;                                                                      // 65
            // },                                                                                                 // 66
            // subscribe: withFilter(                                                                             // 67
            //     () => pubsub.asyncIterator('taskAdded'),                                                       // 68
            //     (root, args, context) => {                                                                     // 69
            //         logger.log('taskAdded subscribe', args, context);                                          // 70
            //         return true;                                                                               // 71
            //     }                                                                                              // 72
            // )                                                                                                  // 73
                                                                                                                  //
        }                                                                                                         // 62
    }                                                                                                             // 61
};                                                                                                                // 33
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"schema.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/schema.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var makeExecutableSchema = void 0;                                                                                // 1
module.watch(require("graphql-tools"), {                                                                          // 1
  makeExecutableSchema: function (v) {                                                                            // 1
    makeExecutableSchema = v;                                                                                     // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
var loadSchema = void 0,                                                                                          // 1
    getSchema = void 0;                                                                                           // 1
module.watch(require("graphql-loader"), {                                                                         // 1
  loadSchema: function (v) {                                                                                      // 1
    loadSchema = v;                                                                                               // 1
  },                                                                                                              // 1
  getSchema: function (v) {                                                                                       // 1
    getSchema = v;                                                                                                // 1
  }                                                                                                               // 1
}, 1);                                                                                                            // 1
var mergeModules = void 0,                                                                                        // 1
    loadModules = void 0;                                                                                         // 1
module.watch(require("graphql-schema-modules"), {                                                                 // 1
  mergeModules: function (v) {                                                                                    // 1
    mergeModules = v;                                                                                             // 1
  },                                                                                                              // 1
  loadModules: function (v) {                                                                                     // 1
    loadModules = v;                                                                                              // 1
  }                                                                                                               // 1
}, 2);                                                                                                            // 1
var initAccounts = void 0;                                                                                        // 1
module.watch(require("meteor/nicolaslopezj:apollo-accounts"), {                                                   // 1
  initAccounts: function (v) {                                                                                    // 1
    initAccounts = v;                                                                                             // 1
  }                                                                                                               // 1
}, 3);                                                                                                            // 1
var date = void 0;                                                                                                // 1
module.watch(require("./gql/date"), {                                                                             // 1
  "default": function (v) {                                                                                       // 1
    date = v;                                                                                                     // 1
  }                                                                                                               // 1
}, 4);                                                                                                            // 1
var json = void 0;                                                                                                // 1
module.watch(require("./gql/json"), {                                                                             // 1
  "default": function (v) {                                                                                       // 1
    json = v;                                                                                                     // 1
  }                                                                                                               // 1
}, 5);                                                                                                            // 1
var hello = void 0;                                                                                               // 1
module.watch(require("./gql/hello"), {                                                                            // 1
  "default": function (v) {                                                                                       // 1
    hello = v;                                                                                                    // 1
  }                                                                                                               // 1
}, 6);                                                                                                            // 1
var response = void 0;                                                                                            // 1
module.watch(require("./gql/response"), {                                                                         // 1
  "default": function (v) {                                                                                       // 1
    response = v;                                                                                                 // 1
  }                                                                                                               // 1
}, 7);                                                                                                            // 1
var categories = void 0;                                                                                          // 1
module.watch(require("./gql/categories"), {                                                                       // 1
  "default": function (v) {                                                                                       // 1
    categories = v;                                                                                               // 1
  }                                                                                                               // 1
}, 8);                                                                                                            // 1
var tasks = void 0;                                                                                               // 1
module.watch(require("./gql/tasks"), {                                                                            // 1
  "default": function (v) {                                                                                       // 1
    tasks = v;                                                                                                    // 1
  }                                                                                                               // 1
}, 9);                                                                                                            // 1
var indiecore = void 0;                                                                                           // 1
module.watch(require("./gql/indiecore"), {                                                                        // 1
  "default": function (v) {                                                                                       // 1
    indiecore = v;                                                                                                // 1
  }                                                                                                               // 1
}, 10);                                                                                                           // 1
initAccounts(); // **** Custom Scalar                                                                             // 6
                                                                                                                  //
// import user from './gql/user';                                                                                 // 17
// const accounts = getSchema()                                                                                   // 18
var _mergeModules = mergeModules([date, json, hello, response, categories, tasks, indiecore]),                    //
    typeDefs = _mergeModules.typeDefs,                                                                            //
    resolvers = _mergeModules.resolvers;                                                                          //
                                                                                                                  //
var schema = makeExecutableSchema({                                                                               // 22
  typeDefs: typeDefs,                                                                                             // 22
  resolvers: resolvers                                                                                            // 22
});                                                                                                               // 22
module.exportDefault(schema);                                                                                     // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"subscriptions.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/subscriptions.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var PubSub = void 0;                                                                                              // 1
module.watch(require("graphql-subscriptions"), {                                                                  // 1
  PubSub: function (v) {                                                                                          // 1
    PubSub = v;                                                                                                   // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
module.exportDefault(new PubSub());                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Categories.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collections/Categories.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                           //
                                                                                                                  //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                  //
                                                                                                                  //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                     //
                                                                                                                  //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                            //
                                                                                                                  //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                       //
                                                                                                                  //
var _inherits3 = _interopRequireDefault(_inherits2);                                                              //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
var Categories = function (_Mongo$Collection) {                                                                   //
  (0, _inherits3.default)(Categories, _Mongo$Collection);                                                         //
                                                                                                                  //
  function Categories() {                                                                                         //
    (0, _classCallCheck3.default)(this, Categories);                                                              //
    return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));              //
  }                                                                                                               //
                                                                                                                  //
  return Categories;                                                                                              //
}(Mongo.Collection);                                                                                              //
                                                                                                                  //
module.exportDefault(new Categories('categories'));                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Tasks.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collections/Tasks.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                           //
                                                                                                                  //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                  //
                                                                                                                  //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                     //
                                                                                                                  //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                            //
                                                                                                                  //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                       //
                                                                                                                  //
var _inherits3 = _interopRequireDefault(_inherits2);                                                              //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
var Tasks = function (_Mongo$Collection) {                                                                        //
  (0, _inherits3.default)(Tasks, _Mongo$Collection);                                                              //
                                                                                                                  //
  function Tasks() {                                                                                              //
    (0, _classCallCheck3.default)(this, Tasks);                                                                   //
    return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));              //
  }                                                                                                               //
                                                                                                                  //
  return Tasks;                                                                                                   //
}(Mongo.Collection);                                                                                              //
                                                                                                                  //
module.exportDefault(new Tasks('tasks'));                                                                         // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collections/index.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({                                                                                                   // 1
  Categories: function () {                                                                                       // 1
    return Categories;                                                                                            // 1
  },                                                                                                              // 1
  Tasks: function () {                                                                                            // 1
    return Tasks;                                                                                                 // 1
  }                                                                                                               // 1
});                                                                                                               // 1
var Categories = void 0;                                                                                          // 1
module.watch(require("./Categories"), {                                                                           // 1
  "default": function (v) {                                                                                       // 1
    Categories = v;                                                                                               // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
var Tasks = void 0;                                                                                               // 1
module.watch(require("./Tasks"), {                                                                                // 1
  "default": function (v) {                                                                                       // 1
    Tasks = v;                                                                                                    // 1
  }                                                                                                               // 1
}, 1);                                                                                                            // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"configs":{"db.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/configs/db.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exportDefault({                                                                                            // 1
    dev: {                                                                                                        // 3
        host: "192.168.0.235",                                                                                    // 4
        username: "konnect",                                                                                      // 5
        password: "kon334IGKL#",                                                                                  // 6
        port: "27017",                                                                                            // 7
        name: "konnect"                                                                                           // 8
    },                                                                                                            // 3
    staging: {                                                                                                    // 10
        host: "192.168.0.235",                                                                                    // 11
        username: "konnect",                                                                                      // 12
        password: "kon334IGKL#",                                                                                  // 13
        port: "27017",                                                                                            // 14
        name: "konnect"                                                                                           // 15
    },                                                                                                            // 10
    live: {                                                                                                       // 17
        host: "192.168.0.235",                                                                                    // 18
        username: "konnect",                                                                                      // 19
        password: "kon334IGKL#",                                                                                  // 20
        port: "27017",                                                                                            // 21
        name: "konnect"                                                                                           // 22
    }                                                                                                             // 17
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"host.js":function(require,exports,module,__filename,__dirname){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/configs/host.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exportDefault({                                                                                            // 1
    dev: {                                                                                                        // 3
        host: "localhost",                                                                                        // 4
        //"192.168.0.86",                                                                                         // 4
        port: 3000,                                                                                               // 5
        absolutePath: __dirname + "/..",                                                                          // 6
        debug: true                                                                                               // 7
    },                                                                                                            // 3
    staging: {                                                                                                    // 9
        host: "192.168.0.235",                                                                                    // 10
        port: 3513,                                                                                               // 11
        absolutePath: __dirname + "/..",                                                                          // 12
        debug: true                                                                                               // 13
    },                                                                                                            // 9
    live: {                                                                                                       // 15
        host: "192.168.0.235",                                                                                    // 16
        port: 3513,                                                                                               // 17
        absolutePath: __dirname + "/..",                                                                          // 18
        debug: false                                                                                              // 19
    }                                                                                                             // 15
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"smtp.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/configs/smtp.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exportDefault({                                                                                            // 1
    dev: {                                                                                                        // 3
        username: 'e.life096@gmail.com',                                                                          // 4
        password: 'unitedcollege',                                                                                // 5
        port: 587,                                                                                                // 6
        server: 'smtp.gmail.com',                                                                                 // 7
        mailFrom: "GraphQL"                                                                                       // 8
    },                                                                                                            // 3
    staging: {                                                                                                    // 10
        username: 'e.life096@gmail.com',                                                                          // 11
        password: 'unitedcollege',                                                                                // 12
        port: 587,                                                                                                // 13
        server: 'smtp.gmail.com',                                                                                 // 14
        mailFrom: "GraphQL"                                                                                       // 15
    },                                                                                                            // 10
    live: {                                                                                                       // 17
        username: '',                                                                                             // 18
        password: 'unitedcollege',                                                                                // 19
        port: 25,                                                                                                 // 20
        server: '',                                                                                               // 21
        mailFrom: ""                                                                                              // 22
    }                                                                                                             // 17
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"logger.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/utils/logger.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exportDefault({                                                                                            // 1
    log: function (event_name) {                                                                                  // 3
        var _console;                                                                                             // 3
                                                                                                                  //
        for (var _len = arguments.length, info = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            info[_key - 1] = arguments[_key];                                                                     // 3
        }                                                                                                         // 3
                                                                                                                  //
        (_console = console).log.apply(_console, [event_name].concat(info));                                      // 4
    },                                                                                                            // 5
    info: function (event_name) {                                                                                 // 7
        var _console2;                                                                                            // 7
                                                                                                                  //
        for (var _len2 = arguments.length, info = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
            info[_key2 - 1] = arguments[_key2];                                                                   // 7
        }                                                                                                         // 7
                                                                                                                  //
        (_console2 = console).info.apply(_console2, [event_name].concat(info));                                   // 8
    },                                                                                                            // 9
    error: function (event_name) {                                                                                // 11
        var _console3;                                                                                            // 11
                                                                                                                  //
        for (var _len3 = arguments.length, info = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
            info[_key3 - 1] = arguments[_key3];                                                                   // 11
        }                                                                                                         // 11
                                                                                                                  //
        (_console3 = console).error.apply(_console3, [event_name].concat(info));                                  // 12
    },                                                                                                            // 14
    warn: function (event_name) {                                                                                 // 16
        var _console4;                                                                                            // 16
                                                                                                                  //
        for (var _len4 = arguments.length, info = Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
            info[_key4 - 1] = arguments[_key4];                                                                   // 16
        }                                                                                                         // 16
                                                                                                                  //
        (_console4 = console).warn.apply(_console4, [event_name].concat(info));                                   // 17
    },                                                                                                            // 18
    trace: function (event_name) {                                                                                // 20
        var _console5;                                                                                            // 20
                                                                                                                  //
        for (var _len5 = arguments.length, info = Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++) {
            info[_key5 - 1] = arguments[_key5];                                                                   // 20
        }                                                                                                         // 20
                                                                                                                  //
        (_console5 = console).trace.apply(_console5, [event_name].concat(info));                                  // 21
    }                                                                                                             // 22
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"regex.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/utils/regex.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exportDefault({                                                                                            // 1
    validateEmail: function (val) {                                                                               // 3
        return (/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(val)
        );                                                                                                        // 4
    },                                                                                                            // 5
    validateEmoji: function (text) {                                                                              // 7
        var reg = /[\uD83C-\uDBFF\uDC00-\uDFFF]+/g;                                                               // 8
        return reg.test(text);                                                                                    // 9
    },                                                                                                            // 10
    validateMobile: function (text) {                                                                             // 12
        return (/^\+(?:[0-9] ?){6,14}[0-9]$/.test(text)                                                           // 13
        ); //return /^\d{9,11}$/.test(val);                                                                       // 13
        /*let mobileRegex = /^(\+|00)(9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7|1)(\s?\d){1,15}$/ ;
          if(mobileRegex.test(text.trim()) && text.trim().length<15 && text.trim().length>=12)                    //
              return true                                                                                         //
          return false*/                                                                                          //
    },                                                                                                            // 19
    validateMobileWithoutCC: function (val) {                                                                     // 21
        return (/^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$/.test(val)                    // 22
        );                                                                                                        // 22
    },                                                                                                            // 23
    validateString: function (val) {                                                                              // 25
        return (/^[a-zA-Z\x20]{3,25}$/.test(val)                                                                  // 26
        );                                                                                                        // 26
    },                                                                                                            // 27
    validateStringMinimumLength2: function (val) {                                                                // 29
        return (/^[a-zA-Z\x20]{2,25}$/.test(val)                                                                  // 30
        );                                                                                                        // 30
    },                                                                                                            // 31
    validatePassword: function (val) {                                                                            // 33
        return (/^(?=.*[A-Za-z])(?=.*[0-9])[A-Za-z0-9!@#$%^&*_]\S{5,16}$/.test(val)                               // 34
        );                                                                                                        // 34
    },                                                                                                            // 35
    validateNumbers: function (val) {                                                                             // 37
        return (/^[0-9]{0,}$/.test(val)                                                                           // 38
        );                                                                                                        // 38
    },                                                                                                            // 39
    validateURL: function (url) {                                                                                 // 41
        return (/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)$/.test(url)
        );                                                                                                        // 42
    },                                                                                                            // 43
    validatePrice: function (val) {                                                                               // 45
        return (/^(\d*([.,](?=\d{1}))?\d+)?$/.test(val)                                                           // 46
        );                                                                                                        // 46
    },                                                                                                            // 47
    validateAlphaNumberic: function (val) {                                                                       // 49
        return (/^[a-zA-Z0-9]*$/.test(val)                                                                        // 50
        );                                                                                                        // 50
    },                                                                                                            // 51
    getNumbericValuesFromString: function (val) {                                                                 // 53
        return val.match(/^\d+|\d+\b|\d+(?=\w)/g);                                                                // 54
    },                                                                                                            // 55
    validateDecimalNumbers: function (val) {                                                                      // 57
        return (/^((\d|[1-9]\d+)(\.\d{0,1})?|\.\d{0,1})$/.test(val)                                               // 58
        );                                                                                                        // 58
    },                                                                                                            // 59
    buildRegExp: function (searchText) {                                                                          // 61
        var parts = searchText.trim().split(/[ \-\:]+/);                                                          // 62
        return new RegExp("(" + parts.join('|') + ")", "ig");                                                     // 64
    },                                                                                                            // 65
    txtMatch: function (Text) {                                                                                   // 67
        return new RegExp("^" + Text.trim() + "$", "i");                                                          // 68
    }                                                                                                             // 69
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"response.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/utils/response.js                                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exportDefault({                                                                                            // 1
    success: function (resultObj) {                                                                               // 3
        return {                                                                                                  // 4
            'success': true,                                                                                      // 5
            'description': 'ok',                                                                                  // 6
            'data': resultObj                                                                                     // 7
        };                                                                                                        // 4
    },                                                                                                            // 9
    failure: function (errorDesc) {                                                                               // 11
        return {                                                                                                  // 12
            'success': false,                                                                                     // 13
            'description': errorDesc,                                                                             // 14
            'errorCode': 404                                                                                      // 15
        };                                                                                                        // 12
    }                                                                                                             // 17
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rest.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/utils/rest.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exportDefault({                                                                                            // 1
    getRequestContents: function (request) {                                                                      // 3
        switch (request.method) {                                                                                 // 4
            case "GET":                                                                                           // 5
                return _.omit(request.query, '__proto__');                                                        // 6
                                                                                                                  //
            case "POST":                                                                                          // 7
                return _.omit(request.body, '__proto__');                                                         // 8
                                                                                                                  //
            case "PUT":                                                                                           // 9
                return _.omit(request.body, '__proto__');                                                         // 10
                                                                                                                  //
            case "DELETE":                                                                                        // 11
                return _.omit(request.body, '__proto__');                                                         // 12
        }                                                                                                         // 4
    },                                                                                                            // 14
    hasData: function (data) {                                                                                    // 16
        return Object.keys(data).length > 0 ? true : false;                                                       // 17
    },                                                                                                            // 18
    response: function (response) {                                                                               // 20
        var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'success';                 // 20
        var statusCode = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 200;                 // 20
        statusCode = statusCode; // (statusCode === 403) ? 200 : statusCode;                                      // 21
        // ----------------------------------------------------                                                   // 22
                                                                                                                  //
        response.setHeader('Content-Type', 'application/json');                                                   // 23
        response.statusCode = statusCode;                                                                         // 24
        response.end(JSON.stringify(data));                                                                       // 25
    },                                                                                                            // 26
    validate: function (data, pattern) {                                                                          // 28
        return Match.test(data, pattern);                                                                         // 29
    }                                                                                                             // 30
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"server.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/server.js                                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _regenerator = require("babel-runtime/regenerator");                                                          //
                                                                                                                  //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                         //
                                                                                                                  //
var _extends2 = require("babel-runtime/helpers/extends");                                                         //
                                                                                                                  //
var _extends3 = _interopRequireDefault(_extends2);                                                                //
                                                                                                                  //
var _this = this;                                                                                                 //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
    Meteor: function (v) {                                                                                        // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
var WebApp = void 0;                                                                                              // 1
module.watch(require("meteor/webapp"), {                                                                          // 1
    WebApp: function (v) {                                                                                        // 1
        WebApp = v;                                                                                               // 1
    }                                                                                                             // 1
}, 1);                                                                                                            // 1
var cors = void 0;                                                                                                // 1
module.watch(require("cors"), {                                                                                   // 1
    "default": function (v) {                                                                                     // 1
        cors = v;                                                                                                 // 1
    }                                                                                                             // 1
}, 2);                                                                                                            // 1
var createApolloServer = void 0,                                                                                  // 1
    getUserForContext = void 0,                                                                                   // 1
    addCurrentUserToContext = void 0;                                                                             // 1
module.watch(require("meteor/apollo"), {                                                                          // 1
    createApolloServer: function (v) {                                                                            // 1
        createApolloServer = v;                                                                                   // 1
    },                                                                                                            // 1
    getUserForContext: function (v) {                                                                             // 1
        getUserForContext = v;                                                                                    // 1
    },                                                                                                            // 1
    addCurrentUserToContext: function (v) {                                                                       // 1
        addCurrentUserToContext = v;                                                                              // 1
    }                                                                                                             // 1
}, 3);                                                                                                            // 1
var SubscriptionServer = void 0;                                                                                  // 1
module.watch(require("subscriptions-transport-ws"), {                                                             // 1
    SubscriptionServer: function (v) {                                                                            // 1
        SubscriptionServer = v;                                                                                   // 1
    }                                                                                                             // 1
}, 4);                                                                                                            // 1
var execute = void 0,                                                                                             // 1
    subscribe = void 0;                                                                                           // 1
module.watch(require("graphql"), {                                                                                // 1
    execute: function (v) {                                                                                       // 1
        execute = v;                                                                                              // 1
    },                                                                                                            // 1
    subscribe: function (v) {                                                                                     // 1
        subscribe = v;                                                                                            // 1
    }                                                                                                             // 1
}, 5);                                                                                                            // 1
var logger = void 0;                                                                                              // 1
module.watch(require("/imports/utils/logger"), {                                                                  // 1
    "default": function (v) {                                                                                     // 1
        logger = v;                                                                                               // 1
    }                                                                                                             // 1
}, 6);                                                                                                            // 1
var schema = void 0;                                                                                              // 1
module.watch(require("/imports/api/schema"), {                                                                    // 1
    "default": function (v) {                                                                                     // 1
        schema = v;                                                                                               // 1
    }                                                                                                             // 1
}, 7);                                                                                                            // 1
var db = void 0;                                                                                                  // 1
module.watch(require("/imports/configs/db"), {                                                                    // 1
    "default": function (v) {                                                                                     // 1
        db = v;                                                                                                   // 1
    }                                                                                                             // 1
}, 8);                                                                                                            // 1
var host = void 0;                                                                                                // 1
module.watch(require("/imports/configs/host"), {                                                                  // 1
    "default": function (v) {                                                                                     // 1
        host = v;                                                                                                 // 1
    }                                                                                                             // 1
}, 9);                                                                                                            // 1
var smtp = void 0;                                                                                                // 1
module.watch(require("/imports/configs/smtp"), {                                                                  // 1
    "default": function (v) {                                                                                     // 1
        smtp = v;                                                                                                 // 1
    }                                                                                                             // 1
}, 10);                                                                                                           // 1
var instance = Meteor.isDevelopment ? 'dev' : 'staging';                                                          // 30
var db_instance = db[instance];                                                                                   // 31
var host_instance = host[instance];                                                                               // 32
var smtp_instance = smtp[instance];                                                                               // 33
var HOST = host_instance.host;                                                                                    // 35
var PORT = host_instance.port;                                                                                    // 36
var WS_GQL_PATH = '/subscriptions';                                                                               // 37
process.env.MONGO_URL = "mongodb://" + db_instance.username + ":" + db_instance.password + "@" + db_instance.host + ":" + db_instance.port + "/" + db_instance.name;
process.env.MAIL_URL = "smtp://" + encodeURIComponent(smtp_instance.username) + ":" + encodeURIComponent(smtp_instance.password) + "@" + encodeURIComponent(smtp_instance.server) + ":" + smtp_instance.port;
process.env.HTTP_FORWARDED_COUNT = 1;                                                                             // 41
Meteor.startup(function () {                                                                                      // 43
    logger.info("Listening @ " + HOST + ":" + PORT);                                                              // 45
});                                                                                                               // 47
var subscriptionsEndpoint = "ws://" + HOST + ":" + PORT + WS_GQL_PATH;                                            // 49
                                                                                                                  //
var customBuildOptions = function (request, res) {                                                                // 51
    // logger.log('*** request method', request.method, '*** request headers', request.headers);                  // 52
    return {                                                                                                      // 53
        context: {                                                                                                // 54
            headers: request.headers                                                                              // 54
        },                                                                                                        // 54
        // This context object is passed to all resolvers.                                                        // 54
        schema: schema                                                                                            // 55
    };                                                                                                            // 53
};                                                                                                                // 57
                                                                                                                  //
var customBuildConfig = {                                                                                         // 59
    path: '/gql',                                                                                                 // 60
    configServer: function (expressServer) {                                                                      // 61
        return expressServer.use(cors());                                                                         // 61
    },                                                                                                            // 61
    graphiql: true,                                                                                               // 62
    // Meteor.isDevelopment                                                                                       // 62
    graphiqlPath: '/graphiql',                                                                                    // 63
    graphiqlOptions: {                                                                                            // 64
        endpointURL: '/gql',                                                                                      // 65
        subscriptionsEndpoint: subscriptionsEndpoint                                                              // 66
    }                                                                                                             // 64
}; // setup graphql server                                                                                        // 59
                                                                                                                  //
createApolloServer(customBuildOptions, customBuildConfig); // setup subscription server                           // 71
                                                                                                                  //
var subscriptionServer = SubscriptionServer.create({                                                              // 74
    execute: execute,                                                                                             // 75
    subscribe: subscribe,                                                                                         // 76
    schema: schema,                                                                                               // 77
    // onOperation: (message, params, webSocket) => {                                                             // 78
    //     logger.log('onOperation');                                                                             // 79
    // },                                                                                                         // 80
    // onOperationComplete: (webSocket, opId) => {                                                                // 81
    //     logger.log('onOperationComplete');                                                                     // 82
    // },                                                                                                         // 83
    onConnect: function () {                                                                                      // 84
        function _callee(params, webSocket) {                                                                     // 84
            var userContext;                                                                                      // 84
            return _regenerator2.default.async(function () {                                                      // 84
                function _callee$(_context) {                                                                     // 84
                    while (1) {                                                                                   // 84
                        switch (_context.prev = _context.next) {                                                  // 84
                            case 0:                                                                               // 84
                                if (!params.loginToken) {                                                         // 84
                                    _context.next = 6;                                                            // 84
                                    break;                                                                        // 84
                                }                                                                                 // 84
                                                                                                                  //
                                _context.next = 3;                                                                // 84
                                return _regenerator2.default.awrap(getUserForContext(params.loginToken));         // 84
                                                                                                                  //
                            case 3:                                                                               // 84
                                _context.t0 = _context.sent;                                                      // 84
                                _context.next = 7;                                                                // 84
                                break;                                                                            // 84
                                                                                                                  //
                            case 6:                                                                               // 84
                                _context.t0 = {                                                                   // 84
                                    user: null                                                                    // 90
                                };                                                                                // 90
                                                                                                                  //
                            case 7:                                                                               // 84
                                userContext = _context.t0;                                                        // 89
                                return _context.abrupt("return", (0, _extends3.default)({}, userContext));        // 84
                                                                                                                  //
                            case 9:                                                                               // 84
                            case "end":                                                                           // 84
                                return _context.stop();                                                           // 84
                        }                                                                                         // 84
                    }                                                                                             // 84
                }                                                                                                 // 84
                                                                                                                  //
                return _callee$;                                                                                  // 84
            }(), null, _this);                                                                                    // 84
        }                                                                                                         // 84
                                                                                                                  //
        return _callee;                                                                                           // 84
    }() // onDisconnect: (webSocket) => {                                                                         // 84
    //    logger.log('Subscription Disconnected');                                                                // 94
    // }                                                                                                          // 95
                                                                                                                  //
}, {                                                                                                              // 74
    server: WebApp.httpServer,                                                                                    // 97
    path: WS_GQL_PATH                                                                                             // 98
});                                                                                                               // 96
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"upload.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/upload.js                                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
    Meteor: function (v) {                                                                                        // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
var WebApp = void 0;                                                                                              // 1
module.watch(require("meteor/webapp"), {                                                                          // 1
    WebApp: function (v) {                                                                                        // 1
        WebApp = v;                                                                                               // 1
    }                                                                                                             // 1
}, 1);                                                                                                            // 1
var Express = void 0;                                                                                             // 1
module.watch(require("express"), {                                                                                // 1
    "default": function (v) {                                                                                     // 1
        Express = v;                                                                                              // 1
    }                                                                                                             // 1
}, 2);                                                                                                            // 1
var Busboy = void 0;                                                                                              // 1
module.watch(require("busboy"), {                                                                                 // 1
    "default": function (v) {                                                                                     // 1
        Busboy = v;                                                                                               // 1
    }                                                                                                             // 1
}, 3);                                                                                                            // 1
var response = void 0;                                                                                            // 1
module.watch(require("/imports/utils/response"), {                                                                // 1
    "default": function (v) {                                                                                     // 1
        response = v;                                                                                             // 1
    }                                                                                                             // 1
}, 4);                                                                                                            // 1
var rest = void 0;                                                                                                // 1
module.watch(require("/imports/utils/rest"), {                                                                    // 1
    "default": function (v) {                                                                                     // 1
        rest = v;                                                                                                 // 1
    }                                                                                                             // 1
}, 5);                                                                                                            // 1
var app = Express();                                                                                              // 16
app.use('/upload', function (req, res, next) {                                                                    // 18
    res.setHeader('Access-Control-Allow-Origin', '*');                                                            // 19
                                                                                                                  //
    if (req.method === "POST") {                                                                                  // 21
        var files = [],                                                                                           // 23
            filesUrls = []; // Store files in an array and then pass them to request.                             // 23
                                                                                                                  //
        var busboy = new Busboy({                                                                                 // 26
            headers: req.headers                                                                                  // 26
        });                                                                                                       // 26
        busboy.on("file", function (fieldname, file, filename, encoding, mimetype) {                              // 28
            var fileObj = {}; // crate an fileObj object                                                          // 30
                                                                                                                  //
            fileObj.mimeType = mimetype;                                                                          // 32
            fileObj.encoding = encoding;                                                                          // 33
            fileObj.filename = filename; // buffer the read chunks                                                // 34
                                                                                                                  //
            var buffers = [];                                                                                     // 37
            file.on('data', function (data) {                                                                     // 39
                buffers.push(data);                                                                               // 40
            });                                                                                                   // 41
            file.on('end', function () {                                                                          // 43
                // concat the chunks                                                                              // 44
                fileObj.data = Buffer.concat(buffers); // push the image object to the file array                 // 45
                                                                                                                  //
                files.push(fileObj);                                                                              // 47
            });                                                                                                   // 48
        });                                                                                                       // 50
        busboy.on("field", function (fieldname, value) {                                                          // 52
            req.body[fieldname] = value;                                                                          // 53
        });                                                                                                       // 54
        busboy.on("finish", Meteor.bindEnvironment(function () {                                                  // 56
            // save files data on server and pass urls to client.                                                 // 58
            _.each(files, function (file) {                                                                       // 60
                rest.response(res, response.success());                                                           // 62
            });                                                                                                   // 64
        })); // Pass request to busboy                                                                            // 66
                                                                                                                  //
        req.pipe(busboy);                                                                                         // 69
    } else {                                                                                                      // 71
        res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');          // 72
        res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');                                           // 73
        res.end('Set OPTIONS.');                                                                                  // 74
    }                                                                                                             // 75
});                                                                                                               // 77
WebApp.connectHandlers.use(Meteor.bindEnvironment(app));                                                          // 79
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/server.js");
require("./server/upload.js");
//# sourceMappingURL=app.js.map
