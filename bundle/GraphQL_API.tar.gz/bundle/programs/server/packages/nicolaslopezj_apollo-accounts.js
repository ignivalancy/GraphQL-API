(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var Accounts = Package['accounts-base'].Accounts;
var NpmModuleBcrypt = Package['npm-bcrypt'].NpmModuleBcrypt;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var OAuth = Package.oauth.OAuth;
var Oauth = Package.oauth.Oauth;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;

var require = meteorInstall({"node_modules":{"meteor":{"nicolaslopezj:apollo-accounts":{"src":{"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/index.js                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");                                        //
                                                                                                                     //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                               //
                                                                                                                     //
var _extends2 = require("babel-runtime/helpers/extends");                                                            //
                                                                                                                     //
var _extends3 = _interopRequireDefault(_extends2);                                                                   //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
module.export({                                                                                                      // 1
  callMethod: function () {                                                                                          // 1
    return callMethod;                                                                                               // 1
  },                                                                                                                 // 1
  initAccounts: function () {                                                                                        // 1
    return initAccounts;                                                                                             // 1
  }                                                                                                                  // 1
});                                                                                                                  // 1
module.watch(require("./checkNpm"));                                                                                 // 1
var SchemaTypes = void 0;                                                                                            // 1
module.watch(require("./Auth"), {                                                                                    // 1
  "default": function (v) {                                                                                          // 1
    SchemaTypes = v;                                                                                                 // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var SchemaMutations = void 0;                                                                                        // 1
module.watch(require("./Mutations"), {                                                                               // 1
  "default": function (v) {                                                                                          // 1
    SchemaMutations = v;                                                                                             // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
var Mutation = void 0;                                                                                               // 1
module.watch(require("./Mutation"), {                                                                                // 1
  "default": function (v) {                                                                                          // 1
    Mutation = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 2);                                                                                                               // 1
var LoginMethodResponse = void 0;                                                                                    // 1
module.watch(require("./LoginMethodResponse"), {                                                                     // 1
  "default": function (v) {                                                                                          // 1
    LoginMethodResponse = v;                                                                                         // 1
  }                                                                                                                  // 1
}, 3);                                                                                                               // 1
var callMethod = void 0;                                                                                             // 1
module.watch(require("./callMethod"), {                                                                              // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 4);                                                                                                               // 1
var loadSchema = void 0;                                                                                             // 1
module.watch(require("graphql-loader"), {                                                                            // 1
  loadSchema: function (v) {                                                                                         // 1
    loadSchema = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 5);                                                                                                               // 1
                                                                                                                     //
var initAccounts = function (givenOptions) {                                                                         // 9
  var defaultOptions = {                                                                                             // 10
    CreateUserProfileInput: 'name: String',                                                                          // 11
    loginWithFacebook: false,                                                                                        // 12
    loginWithGoogle: false,                                                                                          // 13
    loginWithLinkedIn: false,                                                                                        // 14
    loginWithPassword: true                                                                                          // 15
  };                                                                                                                 // 10
  var options = (0, _extends3.default)({}, defaultOptions, givenOptions);                                            // 17
  var typeDefs = [SchemaTypes(options)].concat((0, _toConsumableArray3.default)(SchemaMutations(options)));          // 22
  var resolvers = (0, _extends3.default)({}, Mutation(options), LoginMethodResponse(options));                       // 23
  loadSchema({                                                                                                       // 25
    typeDefs: typeDefs,                                                                                              // 25
    resolvers: resolvers                                                                                             // 25
  });                                                                                                                // 25
};                                                                                                                   // 26
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Auth.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Auth.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.exportDefault(function (options) {                                                                            // 1
  return "\n# Type returned when the user logs in\ntype LoginMethodResponse {\n  # Id of the user logged in user\n  id: String!\n  # Token of the connection\n  token: String!\n  # Expiration date for the token\n  tokenExpires: Float!\n  # The logged in user\n  user: User\n}\n\ninput CreateUserProfileInput {\n  " + options.CreateUserProfileInput + "\n}\n\ntype SuccessResponse {\n  # True if it succeeded\n  success: Boolean\n}\n\n# A hashsed password\ninput HashedPassword {\n  # The hashed password\n  digest: String!\n  # Algorithm used to hash the password\n  algorithm: String!\n}\n";
});                                                                                                                  // 32
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"LoginMethodResponse.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/LoginMethodResponse.js                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor = void 0;                                                                                                 // 1
module.watch(require("meteor/meteor"), {                                                                             // 1
  Meteor: function (v) {                                                                                             // 1
    Meteor = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function (options) {                                                                            // 1
  return {                                                                                                           // 4
    LoginMethodResponse: {                                                                                           // 5
      user: function (_ref) {                                                                                        // 6
        var id = _ref.id;                                                                                            // 6
        return Meteor.users.findOne(id);                                                                             // 7
      }                                                                                                              // 8
    }                                                                                                                // 5
  };                                                                                                                 // 4
});                                                                                                                  // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Mutations.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutations.js                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var hasService = void 0;                                                                                             // 1
module.watch(require("./Mutation/oauth/hasService"), {                                                               // 1
  "default": function (v) {                                                                                          // 1
    hasService = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function (options) {                                                                            // 1
  var mutations = [];                                                                                                // 4
                                                                                                                     //
  if (hasService(options, 'password')) {                                                                             // 6
    mutations.push("\n    type Mutation {\n      # Log the user in with a password.\n      loginWithPassword (username: String, email: String, password: HashedPassword, plainPassword: String): LoginMethodResponse\n\n      # Create a new user.\n      createUser (username: String, email: String, password: HashedPassword, plainPassword: String, profile: CreateUserProfileInput): LoginMethodResponse\n\n      # Change the current user's password. Must be logged in.\n      changePassword (oldPassword: HashedPassword!, newPassword: HashedPassword!): SuccessResponse\n\n      # Request a forgot password email.\n      forgotPassword (email: String!): SuccessResponse\n\n      # Reset the password for a user using a token received in email. Logs the user in afterwards.\n      resetPassword (newPassword: HashedPassword!, token: String!): LoginMethodResponse\n    }");
  }                                                                                                                  // 24
                                                                                                                     //
  mutations.push("\n  type Mutation {\n    # Log the user out.\n    logout (token: String!): SuccessResponse\n\n    # Marks the user's email address as verified. Logs the user in afterwards.\n    verifyEmail (token: String!): LoginMethodResponse\n\n    # Send an email with a link the user can use verify their email address.\n    resendVerificationEmail (email: String): SuccessResponse\n  }");
                                                                                                                     //
  if (hasService(options, 'facebook')) {                                                                             // 38
    mutations.push("\n    type Mutation {\n      # Login the user with a facebook access token\n      loginWithFacebook (accessToken: String!): LoginMethodResponse\n    }");
  }                                                                                                                  // 44
                                                                                                                     //
  if (hasService(options, 'google')) {                                                                               // 46
    mutations.push("\n    type Mutation {\n      # Login the user with a facebook access token\n      loginWithGoogle (accessToken: String!, tokenId: String): LoginMethodResponse\n    }");
  }                                                                                                                  // 52
                                                                                                                     //
  if (hasService(options, 'linkedin')) {                                                                             // 54
    mutations.push("\n    type Mutation {\n      # Login the user with a facebook access token\n      loginWithLinkedIn (code: String!, redirectUri: String!): LoginMethodResponse\n    }");
  }                                                                                                                  // 60
                                                                                                                     //
  return mutations;                                                                                                  // 62
});                                                                                                                  // 63
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"callMethod.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/callMethod.js                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _extends2 = require("babel-runtime/helpers/extends");                                                            //
                                                                                                                     //
var _extends3 = _interopRequireDefault(_extends2);                                                                   //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var Meteor = void 0;                                                                                                 // 1
module.watch(require("meteor/meteor"), {                                                                             // 1
  Meteor: function (v) {                                                                                             // 1
    Meteor = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var getConnection = void 0;                                                                                          // 1
module.watch(require("./getConnection"), {                                                                           // 1
  "default": function (v) {                                                                                          // 1
    getConnection = v;                                                                                               // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
module.exportDefault(function (passedContext, name) {                                                                // 1
  var handler = Meteor.default_server.method_handlers[name];                                                         // 5
                                                                                                                     //
  if (!handler) {                                                                                                    // 6
    throw new Meteor.Error(404, "Method '" + name + "' not found");                                                  // 7
  }                                                                                                                  // 8
                                                                                                                     //
  var connection = getConnection();                                                                                  // 10
  var context = (0, _extends3.default)({                                                                             // 11
    connection: connection,                                                                                          // 12
    setUserId: function (userId) {/**                                                                                // 13
                                   * This will not make any changes if you don\'t pass setUserId function in context
                                   */}                                                                               //
  }, passedContext);                                                                                                 // 11
                                                                                                                     //
  for (var _len = arguments.length, args = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {          // 4
    args[_key - 2] = arguments[_key];                                                                                // 4
  }                                                                                                                  // 4
                                                                                                                     //
  return handler.call.apply(handler, [context].concat(args));                                                        // 21
});                                                                                                                  // 22
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"checkNpm.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/checkNpm.js                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var checkNpmVersions = void 0;                                                                                       // 1
module.watch(require("meteor/tmeasday:check-npm-versions"), {                                                        // 1
  checkNpmVersions: function (v) {                                                                                   // 1
    checkNpmVersions = v;                                                                                            // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
checkNpmVersions({                                                                                                   // 3
  'graphql-loader': '1.2.x'                                                                                          // 4
}, 'nicolaslopezj:apollo-accounts');                                                                                 // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"getConnection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/getConnection.js                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Random = void 0;                                                                                                 // 1
module.watch(require("meteor/random"), {                                                                             // 1
  Random: function (v) {                                                                                             // 1
    Random = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  return {                                                                                                           // 4
    id: Random.id(),                                                                                                 // 5
    close: function () {// nothing to close here                                                                     // 6
    }                                                                                                                // 8
  };                                                                                                                 // 4
});                                                                                                                  // 10
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Mutation":{"changePassword.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/changePassword.js                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var callMethod = void 0;                                                                                             // 1
module.watch(require("../callMethod"), {                                                                             // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, _ref, context) {                                                                            // 3
    var oldPassword = _ref.oldPassword,                                                                              // 3
        newPassword = _ref.newPassword;                                                                              // 3
    return _regenerator2.default.async(function () {                                                                 // 3
      function _callee$(_context) {                                                                                  // 3
        while (1) {                                                                                                  // 3
          switch (_context.prev = _context.next) {                                                                   // 3
            case 0:                                                                                                  // 3
              return _context.abrupt("return", callMethod(context, 'changePassword', oldPassword, newPassword));     // 3
                                                                                                                     //
            case 1:                                                                                                  // 3
            case "end":                                                                                              // 3
              return _context.stop();                                                                                // 3
          }                                                                                                          // 3
        }                                                                                                            // 3
      }                                                                                                              // 3
                                                                                                                     //
      return _callee$;                                                                                               // 3
    }(), null, this);                                                                                                // 3
  }                                                                                                                  // 3
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"createUser.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/createUser.js                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var callMethod = void 0;                                                                                             // 1
module.watch(require("../callMethod"), {                                                                             // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var hashPassword = void 0;                                                                                           // 1
module.watch(require("./hashPassword"), {                                                                            // 1
  "default": function (v) {                                                                                          // 1
    hashPassword = v;                                                                                                // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
var Meteor = void 0;                                                                                                 // 1
module.watch(require("meteor/meteor"), {                                                                             // 1
  Meteor: function (v) {                                                                                             // 1
    Meteor = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 2);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, options, context) {                                                                         // 5
    return _regenerator2.default.async(function () {                                                                 // 5
      function _callee$(_context) {                                                                                  // 5
        while (1) {                                                                                                  // 5
          switch (_context.prev = _context.next) {                                                                   // 5
            case 0:                                                                                                  // 5
              Meteor._nodeCodeMustBeInFiber();                                                                       // 6
                                                                                                                     //
              if (!(!options.password && !options.plainPassword)) {                                                  // 5
                _context.next = 3;                                                                                   // 5
                break;                                                                                               // 5
              }                                                                                                      // 5
                                                                                                                     //
              throw new Error('Password is required');                                                               // 5
                                                                                                                     //
            case 3:                                                                                                  // 5
              if (!options.password) {                                                                               // 10
                options.password = hashPassword(options.plainPassword);                                              // 11
                delete options.plainPassword;                                                                        // 12
              }                                                                                                      // 13
                                                                                                                     //
              return _context.abrupt("return", callMethod(context, 'createUser', options));                          // 5
                                                                                                                     //
            case 5:                                                                                                  // 5
            case "end":                                                                                              // 5
              return _context.stop();                                                                                // 5
          }                                                                                                          // 5
        }                                                                                                            // 5
      }                                                                                                              // 5
                                                                                                                     //
      return _callee$;                                                                                               // 5
    }(), null, this);                                                                                                // 5
  }                                                                                                                  // 5
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"forgotPassword.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/forgotPassword.js                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var callMethod = void 0;                                                                                             // 1
module.watch(require("../callMethod"), {                                                                             // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, _ref, context) {                                                                            // 3
    var email = _ref.email;                                                                                          // 3
    return _regenerator2.default.async(function () {                                                                 // 3
      function _callee$(_context) {                                                                                  // 3
        while (1) {                                                                                                  // 3
          switch (_context.prev = _context.next) {                                                                   // 3
            case 0:                                                                                                  // 3
              callMethod(context, 'forgotPassword', {                                                                // 4
                email: email                                                                                         // 4
              });                                                                                                    // 4
              return _context.abrupt("return", {                                                                     // 3
                success: true                                                                                        // 6
              });                                                                                                    // 5
                                                                                                                     //
            case 2:                                                                                                  // 3
            case "end":                                                                                              // 3
              return _context.stop();                                                                                // 3
          }                                                                                                          // 3
        }                                                                                                            // 3
      }                                                                                                              // 3
                                                                                                                     //
      return _callee$;                                                                                               // 3
    }(), null, this);                                                                                                // 3
  }                                                                                                                  // 3
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hashPassword.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/hashPassword.js                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({                                                                                                      // 1
	SHA256: function () {                                                                                               // 1
		return SHA256;                                                                                                     // 1
	}                                                                                                                   // 1
});                                                                                                                  // 1
                                                                                                                     //
var SHA256 = function (s) {                                                                                          // 3
	var chrsz = 8;                                                                                                      // 4
	var hexcase = 0;                                                                                                    // 5
                                                                                                                     //
	function safe_add(x, y) {                                                                                           // 7
		var lsw = (x & 0xFFFF) + (y & 0xFFFF);                                                                             // 8
		var msw = (x >> 16) + (y >> 16) + (lsw >> 16);                                                                     // 9
		return msw << 16 | lsw & 0xFFFF;                                                                                   // 10
	}                                                                                                                   // 11
                                                                                                                     //
	function S(X, n) {                                                                                                  // 13
		return X >>> n | X << 32 - n;                                                                                      // 13
	}                                                                                                                   // 13
                                                                                                                     //
	function R(X, n) {                                                                                                  // 14
		return X >>> n;                                                                                                    // 14
	}                                                                                                                   // 14
                                                                                                                     //
	function Ch(x, y, z) {                                                                                              // 15
		return x & y ^ ~x & z;                                                                                             // 15
	}                                                                                                                   // 15
                                                                                                                     //
	function Maj(x, y, z) {                                                                                             // 16
		return x & y ^ x & z ^ y & z;                                                                                      // 16
	}                                                                                                                   // 16
                                                                                                                     //
	function Sigma0256(x) {                                                                                             // 17
		return S(x, 2) ^ S(x, 13) ^ S(x, 22);                                                                              // 17
	}                                                                                                                   // 17
                                                                                                                     //
	function Sigma1256(x) {                                                                                             // 18
		return S(x, 6) ^ S(x, 11) ^ S(x, 25);                                                                              // 18
	}                                                                                                                   // 18
                                                                                                                     //
	function Gamma0256(x) {                                                                                             // 19
		return S(x, 7) ^ S(x, 18) ^ R(x, 3);                                                                               // 19
	}                                                                                                                   // 19
                                                                                                                     //
	function Gamma1256(x) {                                                                                             // 20
		return S(x, 17) ^ S(x, 19) ^ R(x, 10);                                                                             // 20
	}                                                                                                                   // 20
                                                                                                                     //
	function core_sha256(m, l) {                                                                                        // 22
		var K = [0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5, 0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5, 0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3, 0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174, 0xE49B69C1, 0xEFBE4786, 0xFC19DC6, 0x240CA1CC, 0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA, 0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7, 0xC6E00BF3, 0xD5A79147, 0x6CA6351, 0x14292967, 0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13, 0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85, 0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3, 0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070, 0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5, 0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3, 0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208, 0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2];
		var HASH = [0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19];       // 24
		var W = new Array(64);                                                                                             // 25
		var a, b, c, d, e, f, g, h;                                                                                        // 26
		var T1, T2;                                                                                                        // 27
		m[l >> 5] |= 0x80 << 24 - l % 32;                                                                                  // 29
		m[(l + 64 >> 9 << 4) + 15] = l;                                                                                    // 30
                                                                                                                     //
		for (var i = 0; i < m.length; i += 16) {                                                                           // 32
			a = HASH[0];                                                                                                      // 33
			b = HASH[1];                                                                                                      // 34
			c = HASH[2];                                                                                                      // 35
			d = HASH[3];                                                                                                      // 36
			e = HASH[4];                                                                                                      // 37
			f = HASH[5];                                                                                                      // 38
			g = HASH[6];                                                                                                      // 39
			h = HASH[7];                                                                                                      // 40
                                                                                                                     //
			for (var j = 0; j < 64; j++) {                                                                                    // 42
				if (j < 16) W[j] = m[j + i];else W[j] = safe_add(safe_add(safe_add(Gamma1256(W[j - 2]), W[j - 7]), Gamma0256(W[j - 15])), W[j - 16]);
				T1 = safe_add(safe_add(safe_add(safe_add(h, Sigma1256(e)), Ch(e, f, g)), K[j]), W[j]);                           // 46
				T2 = safe_add(Sigma0256(a), Maj(a, b, c));                                                                       // 47
				h = g;                                                                                                           // 49
				g = f;                                                                                                           // 50
				f = e;                                                                                                           // 51
				e = safe_add(d, T1);                                                                                             // 52
				d = c;                                                                                                           // 53
				c = b;                                                                                                           // 54
				b = a;                                                                                                           // 55
				a = safe_add(T1, T2);                                                                                            // 56
			}                                                                                                                 // 57
                                                                                                                     //
			HASH[0] = safe_add(a, HASH[0]);                                                                                   // 59
			HASH[1] = safe_add(b, HASH[1]);                                                                                   // 60
			HASH[2] = safe_add(c, HASH[2]);                                                                                   // 61
			HASH[3] = safe_add(d, HASH[3]);                                                                                   // 62
			HASH[4] = safe_add(e, HASH[4]);                                                                                   // 63
			HASH[5] = safe_add(f, HASH[5]);                                                                                   // 64
			HASH[6] = safe_add(g, HASH[6]);                                                                                   // 65
			HASH[7] = safe_add(h, HASH[7]);                                                                                   // 66
		}                                                                                                                  // 67
                                                                                                                     //
		return HASH;                                                                                                       // 68
	}                                                                                                                   // 69
                                                                                                                     //
	function str2binb(str) {                                                                                            // 71
		var bin = [];                                                                                                      // 72
		var mask = (1 << chrsz) - 1;                                                                                       // 73
                                                                                                                     //
		for (var i = 0; i < str.length * chrsz; i += chrsz) {                                                              // 74
			bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << 24 - i % 32;                                                 // 75
		}                                                                                                                  // 76
                                                                                                                     //
		return bin;                                                                                                        // 77
	}                                                                                                                   // 78
                                                                                                                     //
	function Utf8Encode(string) {                                                                                       // 80
		// METEOR change:                                                                                                  // 81
		// The webtoolkit.info version of this code added this                                                             // 82
		// Utf8Encode function (which does seem necessary for dealing                                                      // 83
		// with arbitrary Unicode), but the following line seems                                                           // 84
		// problematic:                                                                                                    // 85
		//                                                                                                                 // 86
		// string = string.replace(/\r\n/g,"\n");                                                                          // 87
		var utftext = "";                                                                                                  // 88
                                                                                                                     //
		for (var n = 0; n < string.length; n++) {                                                                          // 90
			var c = string.charCodeAt(n);                                                                                     // 92
                                                                                                                     //
			if (c < 128) {                                                                                                    // 94
				utftext += String.fromCharCode(c);                                                                               // 95
			} else if (c > 127 && c < 2048) {                                                                                 // 96
				utftext += String.fromCharCode(c >> 6 | 192);                                                                    // 98
				utftext += String.fromCharCode(c & 63 | 128);                                                                    // 99
			} else {                                                                                                          // 100
				utftext += String.fromCharCode(c >> 12 | 224);                                                                   // 102
				utftext += String.fromCharCode(c >> 6 & 63 | 128);                                                               // 103
				utftext += String.fromCharCode(c & 63 | 128);                                                                    // 104
			}                                                                                                                 // 105
		}                                                                                                                  // 107
                                                                                                                     //
		return utftext;                                                                                                    // 109
	}                                                                                                                   // 110
                                                                                                                     //
	function binb2hex(binarray) {                                                                                       // 112
		var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";                                                   // 113
		var str = "";                                                                                                      // 114
                                                                                                                     //
		for (var i = 0; i < binarray.length * 4; i++) {                                                                    // 115
			str += hex_tab.charAt(binarray[i >> 2] >> (3 - i % 4) * 8 + 4 & 0xF) + hex_tab.charAt(binarray[i >> 2] >> (3 - i % 4) * 8 & 0xF);
		}                                                                                                                  // 118
                                                                                                                     //
		return str;                                                                                                        // 119
	}                                                                                                                   // 120
                                                                                                                     //
	s = Utf8Encode(s);                                                                                                  // 122
	return binb2hex(core_sha256(str2binb(s), s.length * chrsz));                                                        // 123
};                                                                                                                   // 124
                                                                                                                     //
module.exportDefault(function (password) {                                                                           // 1
	return {                                                                                                            // 127
		digest: SHA256(password),                                                                                          // 128
		algorithm: 'sha-256'                                                                                               // 129
	};                                                                                                                  // 127
});                                                                                                                  // 131
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/index.js                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _extends2 = require("babel-runtime/helpers/extends");                                                            //
                                                                                                                     //
var _extends3 = _interopRequireDefault(_extends2);                                                                   //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var loginWithPassword = void 0;                                                                                      // 1
module.watch(require("./loginWithPassword"), {                                                                       // 1
  "default": function (v) {                                                                                          // 1
    loginWithPassword = v;                                                                                           // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var logout = void 0;                                                                                                 // 1
module.watch(require("./logout"), {                                                                                  // 1
  "default": function (v) {                                                                                          // 1
    logout = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
var changePassword = void 0;                                                                                         // 1
module.watch(require("./changePassword"), {                                                                          // 1
  "default": function (v) {                                                                                          // 1
    changePassword = v;                                                                                              // 1
  }                                                                                                                  // 1
}, 2);                                                                                                               // 1
var createUser = void 0;                                                                                             // 1
module.watch(require("./createUser"), {                                                                              // 1
  "default": function (v) {                                                                                          // 1
    createUser = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 3);                                                                                                               // 1
var verifyEmail = void 0;                                                                                            // 1
module.watch(require("./verifyEmail"), {                                                                             // 1
  "default": function (v) {                                                                                          // 1
    verifyEmail = v;                                                                                                 // 1
  }                                                                                                                  // 1
}, 4);                                                                                                               // 1
var resendVerificationEmail = void 0;                                                                                // 1
module.watch(require("./resendVerificationEmail"), {                                                                 // 1
  "default": function (v) {                                                                                          // 1
    resendVerificationEmail = v;                                                                                     // 1
  }                                                                                                                  // 1
}, 5);                                                                                                               // 1
var forgotPassword = void 0;                                                                                         // 1
module.watch(require("./forgotPassword"), {                                                                          // 1
  "default": function (v) {                                                                                          // 1
    forgotPassword = v;                                                                                              // 1
  }                                                                                                                  // 1
}, 6);                                                                                                               // 1
var resetPassword = void 0;                                                                                          // 1
module.watch(require("./resetPassword"), {                                                                           // 1
  "default": function (v) {                                                                                          // 1
    resetPassword = v;                                                                                               // 1
  }                                                                                                                  // 1
}, 7);                                                                                                               // 1
var oauth = void 0;                                                                                                  // 1
module.watch(require("./oauth"), {                                                                                   // 1
  "default": function (v) {                                                                                          // 1
    oauth = v;                                                                                                       // 1
  }                                                                                                                  // 1
}, 8);                                                                                                               // 1
var hasService = void 0;                                                                                             // 1
module.watch(require("./oauth/hasService"), {                                                                        // 1
  "default": function (v) {                                                                                          // 1
    hasService = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 9);                                                                                                               // 1
module.exportDefault(function (options) {                                                                            // 1
  var resolvers = (0, _extends3.default)({                                                                           // 13
    logout: logout,                                                                                                  // 14
    verifyEmail: verifyEmail,                                                                                        // 15
    resendVerificationEmail: resendVerificationEmail                                                                 // 16
  }, oauth(options));                                                                                                // 13
                                                                                                                     //
  if (hasService(options, 'password')) {                                                                             // 20
    resolvers.loginWithPassword = loginWithPassword;                                                                 // 21
    resolvers.changePassword = changePassword;                                                                       // 22
    resolvers.createUser = createUser;                                                                               // 23
    resolvers.forgotPassword = forgotPassword;                                                                       // 24
    resolvers.resetPassword = resetPassword;                                                                         // 25
  }                                                                                                                  // 26
                                                                                                                     //
  return {                                                                                                           // 28
    Mutation: resolvers                                                                                              // 28
  };                                                                                                                 // 28
});                                                                                                                  // 29
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginWithPassword.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/loginWithPassword.js                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var callMethod = void 0;                                                                                             // 1
module.watch(require("../callMethod"), {                                                                             // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var hashPassword = void 0;                                                                                           // 1
module.watch(require("./hashPassword"), {                                                                            // 1
  "default": function (v) {                                                                                          // 1
    hashPassword = v;                                                                                                // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
var getUserLoginMethod = void 0;                                                                                     // 1
module.watch(require("./oauth/getUserLoginMethod"), {                                                                // 1
  "default": function (v) {                                                                                          // 1
    getUserLoginMethod = v;                                                                                          // 1
  }                                                                                                                  // 1
}, 2);                                                                                                               // 1
var Meteor = void 0;                                                                                                 // 1
module.watch(require("meteor/meteor"), {                                                                             // 1
  Meteor: function (v) {                                                                                             // 1
    Meteor = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 3);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, _ref, context) {                                                                            // 6
    var username = _ref.username,                                                                                    // 6
        email = _ref.email,                                                                                          // 6
        password = _ref.password,                                                                                    // 6
        plainPassword = _ref.plainPassword;                                                                          // 6
    var methodArguments, method;                                                                                     // 6
    return _regenerator2.default.async(function () {                                                                 // 6
      function _callee$(_context) {                                                                                  // 6
        while (1) {                                                                                                  // 6
          switch (_context.prev = _context.next) {                                                                   // 6
            case 0:                                                                                                  // 6
              if (!(!password && !plainPassword)) {                                                                  // 6
                _context.next = 2;                                                                                   // 6
                break;                                                                                               // 6
              }                                                                                                      // 6
                                                                                                                     //
              throw new Error('Password is required');                                                               // 6
                                                                                                                     //
            case 2:                                                                                                  // 6
              if (!password) {                                                                                       // 10
                password = hashPassword(plainPassword);                                                              // 11
              }                                                                                                      // 12
                                                                                                                     //
              methodArguments = {                                                                                    // 14
                user: email ? {                                                                                      // 15
                  email: email                                                                                       // 15
                } : {                                                                                                // 15
                  username: username                                                                                 // 15
                },                                                                                                   // 15
                password: password                                                                                   // 16
              };                                                                                                     // 14
              _context.prev = 4;                                                                                     // 6
              return _context.abrupt("return", callMethod(context, 'login', methodArguments));                       // 6
                                                                                                                     //
            case 8:                                                                                                  // 6
              _context.prev = 8;                                                                                     // 6
              _context.t0 = _context["catch"](4);                                                                    // 6
                                                                                                                     //
              if (!(_context.t0.reason === 'User has no password set')) {                                            // 6
                _context.next = 23;                                                                                  // 6
                break;                                                                                               // 6
              }                                                                                                      // 6
                                                                                                                     //
              method = getUserLoginMethod(email || username);                                                        // 22
                                                                                                                     //
              if (!(method === 'no-password')) {                                                                     // 6
                _context.next = 16;                                                                                  // 6
                break;                                                                                               // 6
              }                                                                                                      // 6
                                                                                                                     //
              throw new Meteor.Error('no-password', 'User has no password set, go to forgot password');              // 6
                                                                                                                     //
            case 16:                                                                                                 // 6
              if (!method) {                                                                                         // 6
                _context.next = 20;                                                                                  // 6
                break;                                                                                               // 6
              }                                                                                                      // 6
                                                                                                                     //
              throw new Error("User is registered with " + method + ".");                                            // 6
                                                                                                                     //
            case 20:                                                                                                 // 6
              throw new Error('User has no login methods');                                                          // 6
                                                                                                                     //
            case 21:                                                                                                 // 6
              _context.next = 24;                                                                                    // 6
              break;                                                                                                 // 6
                                                                                                                     //
            case 23:                                                                                                 // 6
              throw _context.t0;                                                                                     // 6
                                                                                                                     //
            case 24:                                                                                                 // 6
            case "end":                                                                                              // 6
              return _context.stop();                                                                                // 6
          }                                                                                                          // 6
        }                                                                                                            // 6
      }                                                                                                              // 6
                                                                                                                     //
      return _callee$;                                                                                               // 6
    }(), null, this, [[4, 8]]);                                                                                      // 6
  }                                                                                                                  // 6
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logout.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/logout.js                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var Accounts = void 0;                                                                                               // 1
module.watch(require("meteor/accounts-base"), {                                                                      // 1
  Accounts: function (v) {                                                                                           // 1
    Accounts = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var getConnection = void 0;                                                                                          // 1
module.watch(require("../getConnection"), {                                                                          // 1
  "default": function (v) {                                                                                          // 1
    getConnection = v;                                                                                               // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, _ref, context) {                                                                            // 4
    var token = _ref.token;                                                                                          // 4
    var hashedToken, connection;                                                                                     // 4
    return _regenerator2.default.async(function () {                                                                 // 4
      function _callee$(_context) {                                                                                  // 4
        while (1) {                                                                                                  // 4
          switch (_context.prev = _context.next) {                                                                   // 4
            case 0:                                                                                                  // 4
              if (token && context.userId) {                                                                         // 5
                hashedToken = Accounts._hashLoginToken(token);                                                       // 6
                Accounts.destroyToken(context.userId, hashedToken);                                                  // 7
              }                                                                                                      // 8
                                                                                                                     //
              connection = getConnection();                                                                          // 9
                                                                                                                     //
              Accounts._successfulLogout(connection, context.userId);                                                // 10
                                                                                                                     //
              return _context.abrupt("return", {                                                                     // 4
                success: true                                                                                        // 11
              });                                                                                                    // 11
                                                                                                                     //
            case 4:                                                                                                  // 4
            case "end":                                                                                              // 4
              return _context.stop();                                                                                // 4
          }                                                                                                          // 4
        }                                                                                                            // 4
      }                                                                                                              // 4
                                                                                                                     //
      return _callee$;                                                                                               // 4
    }(), null, this);                                                                                                // 4
  }                                                                                                                  // 4
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resendVerificationEmail.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/resendVerificationEmail.js                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var Accounts = void 0;                                                                                               // 1
module.watch(require("meteor/accounts-base"), {                                                                      // 1
  Accounts: function (v) {                                                                                           // 1
    Accounts = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, _ref, _ref2) {                                                                              // 3
    var email = _ref.email;                                                                                          // 3
    var userId = _ref2.userId;                                                                                       // 3
    return _regenerator2.default.async(function () {                                                                 // 3
      function _callee$(_context) {                                                                                  // 3
        while (1) {                                                                                                  // 3
          switch (_context.prev = _context.next) {                                                                   // 3
            case 0:                                                                                                  // 3
              Accounts.sendVerificationEmail(userId, email);                                                         // 4
              return _context.abrupt("return", {                                                                     // 3
                success: true                                                                                        // 6
              });                                                                                                    // 5
                                                                                                                     //
            case 2:                                                                                                  // 3
            case "end":                                                                                              // 3
              return _context.stop();                                                                                // 3
          }                                                                                                          // 3
        }                                                                                                            // 3
      }                                                                                                              // 3
                                                                                                                     //
      return _callee$;                                                                                               // 3
    }(), null, this);                                                                                                // 3
  }                                                                                                                  // 3
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resetPassword.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/resetPassword.js                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var callMethod = void 0;                                                                                             // 1
module.watch(require("../callMethod"), {                                                                             // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, _ref, context) {                                                                            // 3
    var token = _ref.token,                                                                                          // 3
        newPassword = _ref.newPassword;                                                                              // 3
    return _regenerator2.default.async(function () {                                                                 // 3
      function _callee$(_context) {                                                                                  // 3
        while (1) {                                                                                                  // 3
          switch (_context.prev = _context.next) {                                                                   // 3
            case 0:                                                                                                  // 3
              return _context.abrupt("return", callMethod(context, 'resetPassword', token, newPassword));            // 3
                                                                                                                     //
            case 1:                                                                                                  // 3
            case "end":                                                                                              // 3
              return _context.stop();                                                                                // 3
          }                                                                                                          // 3
        }                                                                                                            // 3
      }                                                                                                              // 3
                                                                                                                     //
      return _callee$;                                                                                               // 3
    }(), null, this);                                                                                                // 3
  }                                                                                                                  // 3
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"verifyEmail.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/verifyEmail.js                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var callMethod = void 0;                                                                                             // 1
module.watch(require("../callMethod"), {                                                                             // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function () {                                                                                   // 1
  function _callee(root, _ref, context) {                                                                            // 3
    var token = _ref.token;                                                                                          // 3
    return _regenerator2.default.async(function () {                                                                 // 3
      function _callee$(_context) {                                                                                  // 3
        while (1) {                                                                                                  // 3
          switch (_context.prev = _context.next) {                                                                   // 3
            case 0:                                                                                                  // 3
              return _context.abrupt("return", callMethod(context, 'verifyEmail', token));                           // 3
                                                                                                                     //
            case 1:                                                                                                  // 3
            case "end":                                                                                              // 3
              return _context.stop();                                                                                // 3
          }                                                                                                          // 3
        }                                                                                                            // 3
      }                                                                                                              // 3
                                                                                                                     //
      return _callee$;                                                                                               // 3
    }(), null, this);                                                                                                // 3
  }                                                                                                                  // 3
                                                                                                                     //
  return _callee;                                                                                                    // 1
}());                                                                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oauth":{"getUserLoginMethod.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/oauth/getUserLoginMethod.js                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");                                        //
                                                                                                                     //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                               //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var Accounts = void 0;                                                                                               // 1
module.watch(require("meteor/accounts-base"), {                                                                      // 1
  Accounts: function (v) {                                                                                           // 1
    Accounts = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
module.exportDefault(function (email) {                                                                              // 1
  if (!email) return 'unknown';                                                                                      // 4
                                                                                                                     //
  var _ref = email.indexOf('@') !== -1 ? Accounts.findUserByEmail(email) : Accounts.findUserByUsername(email),       // 3
      services = _ref.services;                                                                                      // 3
                                                                                                                     //
  var list = [];                                                                                                     // 6
                                                                                                                     //
  for (var key in meteorBabelHelpers.sanitizeForInObject(services)) {                                                // 7
    if (key === 'email') continue;                                                                                   // 8
    if (key === 'resume') continue;                                                                                  // 9
                                                                                                                     //
    if (key === 'password' && !services.password.bcrypt) {                                                           // 10
      list.push('no-password');                                                                                      // 11
    } else {                                                                                                         // 12
      list.push(key);                                                                                                // 13
    }                                                                                                                // 14
  }                                                                                                                  // 15
                                                                                                                     //
  var allowedServices = [].concat((0, _toConsumableArray3.default)(Accounts.oauth.serviceNames()), ['password']);    // 16
  return list.filter(function (service) {                                                                            // 17
    return allowedServices.indexOf(service) !== -1;                                                                  // 17
  }).join(', ');                                                                                                     // 17
});                                                                                                                  // 18
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hasService.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/oauth/hasService.js                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.exportDefault(function (options, service) {                                                                   // 1
  if (service === 'facebook') {                                                                                      // 2
    return options.loginWithFacebook;                                                                                // 3
  }                                                                                                                  // 4
                                                                                                                     //
  if (service === 'google') {                                                                                        // 6
    return options.loginWithGoogle;                                                                                  // 7
  }                                                                                                                  // 8
                                                                                                                     //
  if (service === 'password') {                                                                                      // 10
    return options.loginWithPassword;                                                                                // 11
  }                                                                                                                  // 12
                                                                                                                     //
  if (service === 'linkedin') {                                                                                      // 14
    return options.loginWithLinkedIn;                                                                                // 15
  }                                                                                                                  // 16
                                                                                                                     //
  return false;                                                                                                      // 18
});                                                                                                                  // 19
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/oauth/index.js                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var loginWithFacebook = void 0;                                                                                      // 1
module.watch(require("./loginWithFacebook"), {                                                                       // 1
  "default": function (v) {                                                                                          // 1
    loginWithFacebook = v;                                                                                           // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var loginWithGoogle = void 0;                                                                                        // 1
module.watch(require("./loginWithGoogle"), {                                                                         // 1
  "default": function (v) {                                                                                          // 1
    loginWithGoogle = v;                                                                                             // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
var loginWithLinkedIn = void 0;                                                                                      // 1
module.watch(require("./loginWithLinkedIn"), {                                                                       // 1
  "default": function (v) {                                                                                          // 1
    loginWithLinkedIn = v;                                                                                           // 1
  }                                                                                                                  // 1
}, 2);                                                                                                               // 1
var hasService = void 0;                                                                                             // 1
module.watch(require("./hasService"), {                                                                              // 1
  "default": function (v) {                                                                                          // 1
    hasService = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 3);                                                                                                               // 1
var Accounts = void 0;                                                                                               // 1
module.watch(require("meteor/accounts-base"), {                                                                      // 1
  Accounts: function (v) {                                                                                           // 1
    Accounts = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 4);                                                                                                               // 1
module.exportDefault(function (options) {                                                                            // 1
  var oauth = {};                                                                                                    // 8
                                                                                                                     //
  if (hasService(options, 'facebook')) {                                                                             // 10
    oauth.loginWithFacebook = loginWithFacebook;                                                                     // 11
                                                                                                                     //
    try {                                                                                                            // 12
      Accounts.oauth.registerService('facebook');                                                                    // 13
    } catch (error) {// dont log this error                                                                          // 14
    }                                                                                                                // 16
  }                                                                                                                  // 17
                                                                                                                     //
  if (hasService(options, 'google')) {                                                                               // 19
    oauth.loginWithGoogle = loginWithGoogle;                                                                         // 20
                                                                                                                     //
    try {                                                                                                            // 21
      Accounts.oauth.registerService('google');                                                                      // 22
    } catch (error) {// dont log this error                                                                          // 23
    }                                                                                                                // 25
  }                                                                                                                  // 26
                                                                                                                     //
  if (hasService(options, 'linkedin')) {                                                                             // 28
    oauth.loginWithLinkedIn = loginWithLinkedIn;                                                                     // 29
                                                                                                                     //
    try {                                                                                                            // 30
      Accounts.oauth.registerService('linkedin');                                                                    // 31
    } catch (error) {// dont log this error                                                                          // 32
    }                                                                                                                // 34
  }                                                                                                                  // 35
                                                                                                                     //
  return oauth;                                                                                                      // 37
});                                                                                                                  // 38
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginWithFacebook.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/oauth/loginWithFacebook.js                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _extends2 = require("babel-runtime/helpers/extends");                                                            //
                                                                                                                     //
var _extends3 = _interopRequireDefault(_extends2);                                                                   //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var resolver = void 0;                                                                                               // 1
module.watch(require("./resolver"), {                                                                                // 1
  "default": function (v) {                                                                                          // 1
    resolver = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var HTTP = void 0;                                                                                                   // 1
module.watch(require("meteor/http"), {                                                                               // 1
  HTTP: function (v) {                                                                                               // 1
    HTTP = v;                                                                                                        // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
                                                                                                                     //
var handleAuthFromAccessToken = function (_ref) {                                                                    // 4
  var accessToken = _ref.accessToken;                                                                                // 4
  var identity = getIdentity(accessToken);                                                                           // 5
  var serviceData = (0, _extends3.default)({}, identity, {                                                           // 7
    accessToken: accessToken                                                                                         // 9
  });                                                                                                                // 7
  return {                                                                                                           // 12
    serviceName: 'facebook',                                                                                         // 13
    serviceData: serviceData,                                                                                        // 14
    options: {                                                                                                       // 15
      profile: {                                                                                                     // 15
        name: identity.name                                                                                          // 15
      }                                                                                                              // 15
    }                                                                                                                // 15
  };                                                                                                                 // 12
};                                                                                                                   // 17
                                                                                                                     //
var getIdentity = function (accessToken) {                                                                           // 19
  var fields = ['id', 'email', 'name', 'first_name', 'last_name', 'link', 'gender', 'locale', 'age_range'];          // 20
                                                                                                                     //
  try {                                                                                                              // 21
    return HTTP.get('https://graph.facebook.com/v2.8/me', {                                                          // 22
      params: {                                                                                                      // 23
        access_token: accessToken,                                                                                   // 24
        fields: fields.join(',')                                                                                     // 25
      }                                                                                                              // 23
    }).data;                                                                                                         // 22
  } catch (err) {                                                                                                    // 28
    throw new Error('Failed to fetch identity from Google. ' + err.message);                                         // 29
  }                                                                                                                  // 30
};                                                                                                                   // 31
                                                                                                                     //
module.exportDefault(resolver(handleAuthFromAccessToken));                                                           // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginWithGoogle.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/oauth/loginWithGoogle.js                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _extends2 = require("babel-runtime/helpers/extends");                                                            //
                                                                                                                     //
var _extends3 = _interopRequireDefault(_extends2);                                                                   //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var resolver = void 0;                                                                                               // 1
module.watch(require("./resolver"), {                                                                                // 1
  "default": function (v) {                                                                                          // 1
    resolver = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var HTTP = void 0;                                                                                                   // 1
module.watch(require("meteor/http"), {                                                                               // 1
  HTTP: function (v) {                                                                                               // 1
    HTTP = v;                                                                                                        // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
                                                                                                                     //
var handleAuthFromAccessToken = function (_ref) {                                                                    // 4
  var accessToken = _ref.accessToken;                                                                                // 4
  var scopes = getScopes(accessToken);                                                                               // 5
  var identity = getIdentity(accessToken);                                                                           // 6
  var serviceData = (0, _extends3.default)({}, identity, {                                                           // 8
    accessToken: accessToken,                                                                                        // 10
    scopes: scopes                                                                                                   // 11
  });                                                                                                                // 8
  return {                                                                                                           // 14
    serviceName: 'google',                                                                                           // 15
    serviceData: serviceData,                                                                                        // 16
    options: {                                                                                                       // 17
      profile: {                                                                                                     // 17
        name: identity.name                                                                                          // 17
      }                                                                                                              // 17
    }                                                                                                                // 17
  };                                                                                                                 // 14
};                                                                                                                   // 19
                                                                                                                     //
var getIdentity = function (accessToken) {                                                                           // 21
  try {                                                                                                              // 22
    return HTTP.get('https://www.googleapis.com/oauth2/v1/userinfo', {                                               // 23
      params: {                                                                                                      // 23
        access_token: accessToken                                                                                    // 23
      }                                                                                                              // 23
    }).data;                                                                                                         // 23
  } catch (err) {                                                                                                    // 24
    throw new Error('Failed to fetch identity from Google. ' + err.message);                                         // 25
  }                                                                                                                  // 26
};                                                                                                                   // 27
                                                                                                                     //
var getScopes = function (accessToken) {                                                                             // 29
  try {                                                                                                              // 30
    return HTTP.get('https://www.googleapis.com/oauth2/v1/tokeninfo', {                                              // 31
      params: {                                                                                                      // 31
        access_token: accessToken                                                                                    // 31
      }                                                                                                              // 31
    }).data.scope.split(' ');                                                                                        // 31
  } catch (err) {                                                                                                    // 32
    throw new Error('Failed to fetch tokeninfo from Google. ' + err.message);                                        // 33
  }                                                                                                                  // 34
};                                                                                                                   // 35
                                                                                                                     //
module.exportDefault(resolver(handleAuthFromAccessToken));                                                           // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginWithLinkedIn.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/oauth/loginWithLinkedIn.js                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _extends2 = require("babel-runtime/helpers/extends");                                                            //
                                                                                                                     //
var _extends3 = _interopRequireDefault(_extends2);                                                                   //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var resolver = void 0;                                                                                               // 1
module.watch(require("./resolver"), {                                                                                // 1
  "default": function (v) {                                                                                          // 1
    resolver = v;                                                                                                    // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var HTTP = void 0;                                                                                                   // 1
module.watch(require("meteor/http"), {                                                                               // 1
  HTTP: function (v) {                                                                                               // 1
    HTTP = v;                                                                                                        // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
var ServiceConfiguration = void 0;                                                                                   // 1
module.watch(require("meteor/service-configuration"), {                                                              // 1
  ServiceConfiguration: function (v) {                                                                               // 1
    ServiceConfiguration = v;                                                                                        // 1
  }                                                                                                                  // 1
}, 2);                                                                                                               // 1
                                                                                                                     //
var handleAuthFromAccessToken = function (_ref) {                                                                    // 5
  var code = _ref.code,                                                                                              // 5
      redirectUri = _ref.redirectUri;                                                                                // 5
  // works with anything also...                                                                                     // 6
  var accessToken = getAccessToken(code, redirectUri);                                                               // 7
  var identity = getIdentity(accessToken);                                                                           // 8
  var serviceData = (0, _extends3.default)({}, identity, {                                                           // 10
    accessToken: accessToken                                                                                         // 12
  });                                                                                                                // 10
  return {                                                                                                           // 15
    serviceName: 'linkedin',                                                                                         // 16
    serviceData: serviceData,                                                                                        // 17
    options: {                                                                                                       // 18
      profile: {                                                                                                     // 18
        name: identity.firstName + " " + identity.lastName                                                           // 18
      }                                                                                                              // 18
    }                                                                                                                // 18
  };                                                                                                                 // 15
};                                                                                                                   // 20
                                                                                                                     //
var getTokens = function () {                                                                                        // 22
  var result = ServiceConfiguration.configurations.findOne({                                                         // 23
    service: 'linkedin'                                                                                              // 23
  });                                                                                                                // 23
  return {                                                                                                           // 24
    client_id: result.clientId,                                                                                      // 25
    client_secret: result.secret                                                                                     // 26
  };                                                                                                                 // 24
};                                                                                                                   // 28
                                                                                                                     //
var getAccessToken = function (code, redirectUri) {                                                                  // 30
  var response = HTTP.post('https://www.linkedin.com/oauth/v2/accessToken', {                                        // 31
    params: (0, _extends3.default)({                                                                                 // 32
      grant_type: 'authorization_code',                                                                              // 33
      code: code,                                                                                                    // 34
      redirect_uri: redirectUri                                                                                      // 35
    }, getTokens())                                                                                                  // 32
  }).data;                                                                                                           // 31
  return response.access_token;                                                                                      // 40
};                                                                                                                   // 41
                                                                                                                     //
var getIdentity = function (accessToken) {                                                                           // 43
  try {                                                                                                              // 44
    return HTTP.get('https://www.linkedin.com/v1/people/~:(id,email-address,first-name,last-name,headline)', {       // 45
      params: {                                                                                                      // 46
        oauth2_access_token: accessToken,                                                                            // 47
        format: 'json'                                                                                               // 48
      }                                                                                                              // 46
    }).data;                                                                                                         // 45
  } catch (err) {                                                                                                    // 51
    throw new Error('Failed to fetch identity from LinkedIn. ' + err.message);                                       // 52
  }                                                                                                                  // 53
};                                                                                                                   // 54
                                                                                                                     //
module.exportDefault(resolver(handleAuthFromAccessToken));                                                           // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resolver.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_apollo-accounts/src/Mutation/oauth/resolver.js                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _regenerator = require("babel-runtime/regenerator");                                                             //
                                                                                                                     //
var _regenerator2 = _interopRequireDefault(_regenerator);                                                            //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                    //
                                                                                                                     //
var callMethod = void 0;                                                                                             // 1
module.watch(require("../../callMethod"), {                                                                          // 1
  "default": function (v) {                                                                                          // 1
    callMethod = v;                                                                                                  // 1
  }                                                                                                                  // 1
}, 0);                                                                                                               // 1
var getUserLoginMethod = void 0;                                                                                     // 1
module.watch(require("./getUserLoginMethod"), {                                                                      // 1
  "default": function (v) {                                                                                          // 1
    getUserLoginMethod = v;                                                                                          // 1
  }                                                                                                                  // 1
}, 1);                                                                                                               // 1
var Random = void 0;                                                                                                 // 1
module.watch(require("meteor/random"), {                                                                             // 1
  Random: function (v) {                                                                                             // 1
    Random = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 2);                                                                                                               // 1
var OAuth = void 0;                                                                                                  // 1
module.watch(require("meteor/oauth"), {                                                                              // 1
  OAuth: function (v) {                                                                                              // 1
    OAuth = v;                                                                                                       // 1
  }                                                                                                                  // 1
}, 3);                                                                                                               // 1
var Meteor = void 0;                                                                                                 // 1
module.watch(require("meteor/meteor"), {                                                                             // 1
  Meteor: function (v) {                                                                                             // 1
    Meteor = v;                                                                                                      // 1
  }                                                                                                                  // 1
}, 4);                                                                                                               // 1
module.exportDefault(function (handleAuthFromAccessToken) {                                                          // 1
  return function () {                                                                                               // 8
    function _callee(root, params, context) {                                                                        // 8
      var oauthResult, credentialToken, credentialSecret, oauth, email, method;                                      // 8
      return _regenerator2.default.async(function () {                                                               // 8
        function _callee$(_context) {                                                                                // 8
          while (1) {                                                                                                // 8
            switch (_context.prev = _context.next) {                                                                 // 8
              case 0:                                                                                                // 8
                oauthResult = handleAuthFromAccessToken(params); // Why any token works? :/                          // 9
                                                                                                                     //
                credentialToken = Random.secret();                                                                   // 11
                credentialSecret = Random.secret();                                                                  // 12
                                                                                                                     //
                OAuth._storePendingCredential(credentialToken, oauthResult, credentialSecret);                       // 14
                                                                                                                     //
                oauth = {                                                                                            // 16
                  credentialToken: credentialToken,                                                                  // 16
                  credentialSecret: credentialSecret                                                                 // 16
                };                                                                                                   // 16
                _context.prev = 5;                                                                                   // 8
                return _context.abrupt("return", callMethod(context, 'login', {                                      // 8
                  oauth: oauth                                                                                       // 18
                }));                                                                                                 // 18
                                                                                                                     //
              case 9:                                                                                                // 8
                _context.prev = 9;                                                                                   // 8
                _context.t0 = _context["catch"](5);                                                                  // 8
                                                                                                                     //
                if (!(_context.t0.reason === 'Email already exists.')) {                                             // 8
                  _context.next = 25;                                                                                // 8
                  break;                                                                                             // 8
                }                                                                                                    // 8
                                                                                                                     //
                email = oauthResult.serviceData.email || oauthResult.serviceData.emailAddress;                       // 21
                method = getUserLoginMethod(email);                                                                  // 22
                                                                                                                     //
                if (!(method === 'no-password')) {                                                                   // 8
                  _context.next = 18;                                                                                // 8
                  break;                                                                                             // 8
                }                                                                                                    // 8
                                                                                                                     //
                throw new Meteor.Error('no-password', 'User has no password set, go to forgot password');            // 8
                                                                                                                     //
              case 18:                                                                                               // 8
                if (!method) {                                                                                       // 8
                  _context.next = 22;                                                                                // 8
                  break;                                                                                             // 8
                }                                                                                                    // 8
                                                                                                                     //
                throw new Error("User is registered with " + method + ".");                                          // 8
                                                                                                                     //
              case 22:                                                                                               // 8
                throw new Error('User has no login methods');                                                        // 8
                                                                                                                     //
              case 23:                                                                                               // 8
                _context.next = 26;                                                                                  // 8
                break;                                                                                               // 8
                                                                                                                     //
              case 25:                                                                                               // 8
                throw _context.t0;                                                                                   // 8
                                                                                                                     //
              case 26:                                                                                               // 8
              case "end":                                                                                            // 8
                return _context.stop();                                                                              // 8
            }                                                                                                        // 8
          }                                                                                                          // 8
        }                                                                                                            // 8
                                                                                                                     //
        return _callee$;                                                                                             // 8
      }(), null, this, [[5, 9]]);                                                                                    // 8
    }                                                                                                                // 8
                                                                                                                     //
    return _callee;                                                                                                  // 8
  }();                                                                                                               // 8
});                                                                                                                  // 35
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("./node_modules/meteor/nicolaslopezj:apollo-accounts/src/index.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nicolaslopezj:apollo-accounts'] = exports;

})();

//# sourceMappingURL=nicolaslopezj_apollo-accounts.js.map
